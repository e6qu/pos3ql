SQL_HASH='6c32b09b32df274b1f2ecf0be4fbbb87305ff2b8a3947568e6d0d199bad8fbdd'
EXPECTED=['long-primary|pppppppppppppppppppppppppppppppppppppppppppppppppppppppppp_pkey|63|t', 'balanced-unique|ttttttttttttttttttttttttttttt_ccccccccccccccccccccccccccccc_key|63|t', 'unicode-unique|éééééééééééééé_界界界界界界界界界_key|60|t', 'namespace-collision|a|a_b_c_key1|t', 'namespace-collision|a_b|a_b_c_key|t', 'retained-after-renames|a_b_c_key|t|t', 'after-reindex|t|t|t|t|t', 'dropped-by-retained-name|t', 'backing-relations-removed|t']
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert name not in checks and Path(name).name==name
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
assert checks['225_inline_key_names.sql']==SQL_HASH
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert not re.search(r'ERROR:|FATAL:',(root/'reference.stderr').read_text())
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes']==[]
assert SQL_HASH in provenance['sources'].values()
commands=json.loads((root/'commands.json').read_text())
server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
assert all(re.fullmatch('[0-9a-f]{64}',value) for value in provenance['sources'].values())
print(json.dumps({'verified_files':len(checks),'sql_sha256':SQL_HASH,'output_rows':len(EXPECTED),'qualification':'PostgreSQL reference semantics only'}))
