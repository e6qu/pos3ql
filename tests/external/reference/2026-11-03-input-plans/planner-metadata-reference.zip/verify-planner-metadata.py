SQL_HASHES={'232_planner_record_metadata.sql': 'b9918d5eeda4ee445e2c89cda7927524ca2352321b756d6a41b1176f435a070a', 'metadata-catalog-probe.sql': '9b14b6b9244fcdaa0ec001ca7add9099c4f8e86473d617686adf10c440aef763'}
EXPECTED=['7|xy|integer|character varying', 'x|1', 'NULL|2', 'z|3', '9', '1|11|10|11', '2|20|25', 'kept', 'planner_metadata_index|replacement index', 'planner_metadata_retired|original index', 'replacement index', '1978|403|int4_ops|integer_ops|23|t|0', '1979|403|int2_ops|integer_ops|21|t|0', '1981|403|oid_ops|oid_ops|26|t|0', '4217|403|text_pattern_ops|text_pattern_ops|25|f|0', '10028|403|name_ops|text_ops|19|t|2275', '10031|405|oid_ops|oid_ops|26|t|0', '10044|403|varchar_ops|text_ops|25|f|0', '10053|403|xid8_ops|xid8_ops|5069|t|0', '85', '0']
ERRORS=['42703', '42809', '42P01', '42P01', '42809', '42P01', '42P01']
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert Path(name).name==name and name not in checks
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
for name,digest in SQL_HASHES.items():assert checks[name]==digest,name
assert (root/'planner-drop.sql').read_text()=='\n'.join((root/name).read_text() for name in SQL_HASHES)
rows=(root/'reference.stdout').read_text().splitlines()
assert rows[:len(EXPECTED)]==EXPECTED
classes=[line.split('|') for line in rows[len(EXPECTED):] if line.count('|')==6]
families=[line.split('|') for line in rows[len(EXPECTED):] if line.count('|')==2]
assert len(rows)==175 and (len(classes),len(families))==(85,69)
assert len({row[0] for row in classes})==85 and len({row[0] for row in families})==69
assert sum(row[1]=='403' for row in classes)==44
assert sum(row[1]=='405' for row in classes)==41
assert all(any(f[0]==c[3] and f[1]==c[1] for f in families) for c in classes)
assert re.findall(r'ERROR:\s+([A-Z0-9]{5}):',(root/'reference.stderr').read_text())==ERRORS
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes']==ERRORS
assert set(SQL_HASHES.values())<=set(provenance['sources'].values())
commands=json.loads((root/'commands.json').read_text())
server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
print(json.dumps({'verified_files':len(checks),'output_rows':len(rows),'fixture_rows':len(EXPECTED),'classes':len(classes),'families':len(families),'error_codes':ERRORS,'qualification':'PostgreSQL reference semantics only'}))
