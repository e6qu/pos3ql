import hashlib
import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1]).resolve()
manifest = root / 'SHA256SUMS'
recorded = {}
for line in manifest.read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert name == Path(name).name and name not in recorded, name
    recorded[name] = digest
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
assert set(recorded) == {p.name for p in root.iterdir() if p.is_file() and p.name != 'SHA256SUMS'}
provenance = json.loads((root / 'provenance.json').read_text())
assert provenance['version'] == 'postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['purpose'] == 'reference SQL semantics; no pos3ql execution or performance qualification'
assert provenance['observed_error_codes'] == []
assert not re.findall(r'ERROR:\s+([A-Z0-9]{5}):', (root / 'reference.stderr').read_text())
fixture = '219_procedural_loop_scopes.sql'
assert recorded[fixture] == 'b934a4c6c3f4e838aa179b52d276858e35c68edbcb6c8696baccdb9f65e9c5a4'
for source, digest in provenance['sources'].items():
    if Path(source).name in (fixture, 'run-loop-scopes.py'):
        assert recorded[Path(source).name] == digest
expected = ['outer:constant:78', 'tt:2:t:3:6:6:f:null:f', '41', '41', '1', '2', '3', '4', '4',
            '22004,22004,22004,22023,22003,22004', 'null:null', 'assert:cancel']
assert (root / 'reference.stdout').read_text().splitlines() == expected
commands = json.loads((root / 'commands.json').read_text())
server = next(command for command in commands if Path(command[0]).name == 'postgres' and '-D' in command)
for setting in ('listen_addresses=', 'shared_buffers=16MB', 'work_mem=1MB', 'max_connections=5'):
    assert setting in server, setting
assert json.loads((root / 'qualification.json').read_text())['fixture_source_state'] == 'Uncommitted fixture relative to recorded project_revision; exact consumed bytes are archived and hashed.'
print('Verified PostgreSQL 18.6 loop and exception reference.')
