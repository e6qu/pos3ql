import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import tempfile
import time

root = Path(__file__).resolve().parent
output = root / 'generated-key-names-8f59-final'
output.mkdir(exist_ok=False)
prefix = Path('/opt/homebrew/opt/postgresql@18/bin')
commands = []
environment = {key: value for key, value in os.environ.items() if not key.startswith('PG')}
environment.update({'LC_ALL': 'C', 'LANG': 'C', 'PGAPPNAME': 'pos3ql-boundary-reference'})

def execute(arguments, **options):
    commands.append([str(value) for value in arguments])
    return subprocess.run(arguments, env=environment, check=True, text=True, **options)

def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            sha.update(chunk)
    return sha.hexdigest()

version = execute([prefix / 'postgres', '--version'], capture_output=True).stdout.strip()
assert version == 'postgres (PostgreSQL) 18.6 (Homebrew)', version
sql = root.parent / 'share-statistics-capacity/tests/external/differential/228_generated_key_names.sql'
(output / sql.name).write_bytes(sql.read_bytes())
(output / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
provenance = {
    'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'version': version,
    'platform': platform.platform(),
    'project_revision': '8f597543c1e9bcc687d2fbad2f7870c03113b3b7 with uncommitted fixture228; exact source hash recorded',
    'purpose': 'reference SQL semantics; no pos3ql execution or performance qualification',
    'guard': '/Users/zardoz/.codex/tools/fr-local-guard.py',
    'sources': {str(path): digest(path) for path in [sql, Path(__file__), prefix / 'postgres', prefix / 'psql', prefix / 'initdb']},
}
try:
    with tempfile.TemporaryDirectory(prefix='p3-boundary-', dir='/private/tmp') as directory:
        temporary = Path(directory)
        data = temporary / 'data'
        sockets = temporary / 'sockets'
        sockets.mkdir(mode=0o700)
        with (output / 'initdb.stdout').open('w') as stdout, (output / 'initdb.stderr').open('w') as stderr:
            execute([prefix / 'initdb', '--pgdata', data, '--username=postgres', '--auth=trust', '--encoding=UTF8', '--locale=C', '--no-sync'], stdout=stdout, stderr=stderr)
        server_arguments = [str(prefix / 'postgres'), '-D', str(data), '-k', str(sockets), '-p', '56381']
        for setting in ['listen_addresses=', 'shared_buffers=16MB', 'wal_buffers=1MB', 'work_mem=1MB', 'maintenance_work_mem=8MB', 'temp_buffers=1MB', 'max_connections=5', 'superuser_reserved_connections=1', 'autovacuum=off', 'max_worker_processes=0', 'max_wal_senders=0', 'wal_level=minimal', 'fsync=off', 'full_page_writes=off', 'synchronous_commit=off', 'max_wal_size=64MB', 'min_wal_size=32MB', 'timezone=UTC', 'statement_timeout=5s', 'lock_timeout=3s']:
            server_arguments.extend(['-c', setting])
        commands.append(server_arguments)
        with (output / 'server.log').open('w') as log:
            server = subprocess.Popen(server_arguments, stdout=log, stderr=subprocess.STDOUT, env=environment)
            try:
                deadline = time.monotonic() + 20
                ready_arguments = [prefix / 'pg_isready', '-h', sockets, '-p', '56381', '-U', 'postgres', '-d', 'postgres']
                provenance['readiness_command'] = [str(value) for value in ready_arguments]
                provenance['readiness_attempts'] = 0
                while True:
                    provenance['readiness_attempts'] += 1
                    ready = subprocess.run(ready_arguments, env=environment, capture_output=True)
                    if ready.returncode == 0:
                        break
                    if server.poll() is not None or time.monotonic() >= deadline:
                        raise RuntimeError('temporary PostgreSQL reference did not become ready')
                    time.sleep(0.1)
                with (output / 'reference.stdout').open('w') as stdout, (output / 'reference.stderr').open('w') as stderr:
                    execute([prefix / 'psql', '-X', '-q', '-A', '-t', '-h', sockets, '-p', '56381', '-U', 'postgres', '-d', 'postgres', '--set=ON_ERROR_STOP=on', '--set=VERBOSITY=verbose', '-f', sql], stdout=stdout, stderr=stderr)
            finally:
                if server.poll() is None:
                    server.send_signal(signal.SIGINT)
                    try:
                        server.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait()
    errors = re.findall(r'ERROR:\s+([A-Z0-9]{5}):', (output / 'reference.stderr').read_text())
    assert errors == [], errors
    provenance['observed_error_codes'] = errors
    print((output / 'reference.stdout').read_text())
finally:
    (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    files = sorted(path for path in output.iterdir() if path.is_file() and path.name != 'SHA256SUMS')
    (output / 'SHA256SUMS').write_text(''.join(f'{digest(path)}  {path.name}\n' for path in files))
