EXPECTED=['9', 'handler|9:kept:ISO, MDY', '3|60', 't|t|t', '1|t', 'drop|60', 'inner|outer', 'kept|0', '7', '7', '1', 'subtx_old', '2', '12', 'kept|ISO, MDY', 'old_cursor', '7', '0', '1', '3', 't|t', '11', '12', 'after|11|kept', 'after|12|kept', 'before|11|kept', 'before|12|kept', 'statement|2|kept', '99', '99', 'kept', '1002|kept handler', '0']
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert Path(name).name==name and name not in checks
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
inputs=['236_procedural_subtransactions.sql','237_cursor_savepoint_lifetimes.sql','238_caught_schema_recovery.sql','239_trigger_subtransaction_visibility.sql','foreign-setup.sql','foreign-procedural-subtransactions.sql']
assert (root/'procedural-subtransactions.sql').read_text()=='\n\n'.join((root/name).read_text() for name in inputs)
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert re.findall(r'ERROR:\s+([A-Z0-9]{5}):',(root/'reference.stderr').read_text())==['22012','22012','55000']
p=json.loads((root/'provenance.json').read_text());assert p['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert p['observed_error_codes']==['22012','22012','55000']
assert all(checks[name] in p['sources'].values() for name in inputs)
commands=json.loads((root/'commands.json').read_text());server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(s in server for s in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
print(json.dumps({'verified_files':len(checks),'rows':len(EXPECTED),'error_codes':['22012','22012','55000'],'qualification':'PostgreSQL reference semantics only'}))
