SQL_HASHES={'230_planner_constant_order.sql': '9bd52c3e73f0b536bf90f78f63c5b052011cee6c213c8f8abc850de325f4ad9c', '231_index_drop_undo.sql': 'bd554460d7ddf3ca0bcd171f576c72c90afb54db2254378ccc44343142a65a1b'}
EXPECTED=['1', 'integer', 'a_ba_b|0', 'a_ba_b|0', 'a_ba_b|0', 'a_ba_b|0', 'a_ba_b|0', 'a_ba_b|0', '7', '1|t', '2|f', 't', 't', '2', 't', '9', 'drop_owner_pkey', 'drop_parent', 'drop_first', 'drop_owner_pkey', 'drop_parent', 'drop_first', 'drop_owner_pkey', 'drop_parent', '0']
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert Path(name).name==name and name not in checks
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
for name,digest in SQL_HASHES.items(): assert checks[name]==digest,name
assert (root/'planner-drop.sql').read_text()=='\n'.join((root/name).read_text() for name in SQL_HASHES)
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert re.findall(r'ERROR:\s+([A-Z0-9]{5}):',(root/'reference.stderr').read_text())==['42601','42703','22012','42883','22003','42883']
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes']==['42601','42703','22012','42883','22003','42883']
assert set(SQL_HASHES.values()) <= set(provenance['sources'].values())
commands=json.loads((root/'commands.json').read_text())
server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
assert all(re.fullmatch('[0-9a-f]{64}',value) for value in provenance['sources'].values())
print(json.dumps({'verified_files':len(checks),'output_rows':len(EXPECTED),'error_codes':['42601','42703','22012','42883','22003','42883'],'qualification':'PostgreSQL reference semantics only'}))
