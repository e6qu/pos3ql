import hashlib
import json
from pathlib import Path
import sys
root = Path(sys.argv[1])
for line in (root / 'SHA256SUMS').read_text().splitlines():
    checksum, name = line.split('  ', 1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == checksum, name
provenance = json.loads((root / 'provenance.json').read_text())
assert provenance['version'] == 'postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes'] == []
assert not (root / 'reference.stderr').read_text()
expected = ['17|1:ok:true', '28|2:ok:true', '2']
assert (root / 'reference.stdout').read_text().splitlines() == expected
assert (root / '252_local_initializer_layout.sql').read_bytes() == (root / 'local-initializer.sql').read_bytes()
commands = json.loads((root / 'commands.json').read_text())
server = next(command for command in commands if Path(command[0]).name == 'postgres' and '-D' in command)
for setting in ['listen_addresses=', 'shared_buffers=16MB', 'work_mem=1MB', 'max_connections=5', 'statement_timeout=5s', 'lock_timeout=3s']:
    assert setting in server, setting
print('Verified PostgreSQL 18.6: 3 ordered local-initializer rows, zero errors, file hashes and bounded server settings')
