import hashlib
import json
from pathlib import Path
import sys
root=Path(sys.argv[1])
files={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1)
 path=Path(name)
 assert not path.is_absolute() and '..' not in path.parts and name not in files
 assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,name
 files[name]=digest
assert set(files)=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p != root/'SHA256SUMS'}
for name in ['values','procedural']:
 directory=root/name
 p=json.loads((directory/'provenance.json').read_text())
 assert p['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
 assert p['observed_error_codes']==[]
 assert (directory/'reference.stderr').read_text()==''
 for source,digest in p['sources'].items():
  if (directory/Path(source).name).exists():
   assert hashlib.sha256((directory/Path(source).name).read_bytes()).hexdigest()==digest
 for line in (directory/'SHA256SUMS').read_text().splitlines():
  digest,source=line.split('  ',1)
  assert files[name+'/'+source]==digest
assert (root/'values/reference.stdout').read_text().splitlines()==['derived_one|f','derived_two|t','direct_one|f','direct_two|t','projected_effect|t','source_effect|t','union_two|f','1|f']
assert (root/'procedural/reference.stdout').read_text().splitlines()==['perform|3','select|6','for|7','for|9','record|9','record|11','execute_into|11','execute_for|12','execute_for|14','execute_record|14','execute_record|16','execute_discard|1','14','1','17','19','19','21','18','1','31','99','20','33','98','22','1','dynamic|4|6|3','dynamic_strict|4|9|3','static|1|1|1','static_strict|1|3|2']
print(json.dumps({'verified_files':len(files),'observations':['VALUES scroll provenance and deferred effects','procedural row values and checked-input reuse','completed RETURN QUERY rows survive caught SQL errors']}))
