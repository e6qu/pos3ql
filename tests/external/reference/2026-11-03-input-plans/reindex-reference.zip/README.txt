PostgreSQL 18.6 reference semantics for concurrent REINDEX.
Source revision: 5119b065b18405deff619a60a45151fcbdb4fe34.
Probe SQL was external reference-only input; exact executed bytes are included and hashed.
Each probe used fr-local-guard.py with a foreground server, TCP disabled, 16MB shared buffers and five connections.
eligibility preserves the two intentional 0A000 errors and the table exclusion-index warning.
events verifies start/end REINDEX tags, current replacement index identities, stable constraint identities and no internal sql_drop callbacks.
The table event output includes PostgreSQL's TOAST index; its numeric relation identity is run-specific.
toast verifies direct concurrent TOAST index rebuild: stable relation identity, replacement index identity, REINDEX events and no sql_drop.
toast-flags retains all six true pg_index flags including indisprimary, key types/classes, and false index-attribute attnotnull values.
toast-dependencies verifies index auto-dependencies on both TOAST columns and the TOAST relation internal dependency on its owning table.
invalid preserves the intentional 23505 failed build, TABLE warning55000 and notice00000, and successful directINDEX repair with replacement identity.
This is reference behavior evidence, not pos3ql passing-test or performance evidence.
Extract to an empty directory and run: python3 verify-reindex-reference.py EXTRACTED_DIRECTORY
