import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
for line in (root/'SHA256SUMS').read_text().splitlines():
 checksum,name=line.split('  ',1)
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==checksum,name
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes']==[]
assert (root/'reference.stderr').read_text()==''
assert (root/'reference.stdout').read_text().splitlines()==['7:integer:8:P0001:parameter handler:1:integer:7:8','42','7:8','7|output','NULL','NULL','7','dynamic:1:integer:after:text']
assert (root/'trigger-context.sql').read_bytes()==(root/'259_procedural_parameter_scopes.sql').read_bytes()
commands=json.loads((root/'commands.json').read_text())
server=next(command for command in commands if Path(command[0]).name=='postgres' and '-D' in command)
for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5','statement_timeout=5s','lock_timeout=3s']:
 assert setting in server,setting
print('Verified PostgreSQL18.6:8rows,zero errors/notices,hashes and bounded settings')
