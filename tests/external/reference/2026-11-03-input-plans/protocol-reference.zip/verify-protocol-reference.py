import hashlib
import json
from pathlib import Path
import struct
import sys

root = Path(sys.argv[1])
files = {}
for line in (root / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert '/' not in name and name not in files
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
    files[name] = digest
assert set(files) == {p.name for p in root.iterdir() if p.is_file()} - {'SHA256SUMS'}
provenance = json.loads((root / 'provenance.json').read_text())
assert provenance['version'] == 'postgres (PostgreSQL) 18.6 (Homebrew)'
for name, digest in provenance['sources'].items():
    if Path(name).name == 'run-protocol-reference.py':
        assert files[Path(name).name] == digest
records = json.loads((root / 'transcript.json').read_text())
assert all(tag != 'K' for record in records for tag, _ in record['messages'])
assert len({r['label'] for r in records}) < len(records)  # repeated pruning resets are retained
by_label = {}
for record in records:
    by_label.setdefault(record['label'], []).append(record['messages'])

def messages(label):
    assert len(by_label[label]) == 1
    return [(tag, bytes.fromhex(raw)) for tag, raw in by_label[label][0]]

def rows(label):
    result = []
    for tag, value in messages(label):
        if tag != 'D': continue
        count = struct.unpack_from('!h', value)[0]
        position = 2
        row = []
        for _ in range(count):
            size = struct.unpack_from('!i', value, position)[0]
            position += 4
            row.append(None if size < 0 else value[position:position+size].decode())
            position += max(size, 0)
        assert position == len(value)
        result.append(row)
    return result

def error(label):
    errors = [dict((field[:1].decode(), field[1:].decode()) for field in value.split(b'\0') if field) for tag, value in messages(label) if tag == 'E']
    assert len(errors) == 1
    return errors[0]['C']

assert error('portal-duplicate-bind') == '42P03'
assert messages('portal-error-sync') == [('Z', b'E')]
assert error('portal-execute-failed-block') == '25P02'
assert messages('portal-failed-execute-sync') == [('Z', b'E')]
assert messages('portal-rollback')[-1] == ('Z', b'I')
for command, before, after, state, tag in [
    ('CREATE INDEX CONCURRENTLY utility_index ON utility_rows(id)', '1', '1', 'false:true', 'CREATE INDEX'),
    ('REINDEX INDEX CONCURRENTLY utility_index', '1', '1', 'true:true', 'REINDEX'),
    ('DROP INDEX CONCURRENTLY utility_index', '1', '0', 'false:false', 'DROP INDEX'),
    ('CREATE DATABASE utility_database', '1', '1', None, 'CREATE DATABASE'),
    ('DROP DATABASE utility_database', '0', '0', None, 'DROP DATABASE'),
]:
    assert rows('utility-visible-before-sync:' + command) == [[before]]
    assert rows('utility-visible-after-sync:' + command) == [[after]]
    assert rows('utility-index-before-sync:' + command) == ([] if state is None else [[state]])
    assert messages('utility-execute:' + command) == [('C', tag.encode() + b'\0')]
    assert messages('utility-sync:' + command) == [('Z', b'I')]
for parameter, observed, result in [('1', '1:false', '17'), ('0', '1:true', '1'), ('stop', '1:false', '17'), ('go', '1:true', '1')]:
    assert rows('pruning-checks-after-bind:' + parameter) == [[observed]]
    assert rows('pruning-execute:' + parameter) == [[result]]
print(json.dumps({'verified_files': len(files), 'transcript_records': len(records), 'observations': ['failed portal transaction', 'five utility boundaries', 'four branch parameters']}))
