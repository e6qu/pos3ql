CREATE SCHEMA reindex_flags;
CREATE TABLE reindex_flags.rows(id integer PRIMARY KEY,body text);
INSERT INTO reindex_flags.rows VALUES(1,'a');
CREATE TABLE reindex_flags.before AS
 SELECT t.oid AS toast_oid,i.indexrelid AS index_oid
 FROM pg_class t JOIN pg_index i ON i.indrelid=t.oid
 WHERE t.oid=(SELECT reltoastrelid FROM pg_class WHERE oid='reindex_flags.rows'::regclass);
SELECT 'before',i.indisunique,i.indisprimary,i.indisvalid,i.indisready,i.indislive,i.indimmediate,
 i.indkey::text,i.indnkeyatts,i.indnatts,i.indcollation::text,
 (SELECT string_agg(o.opcname,',' ORDER BY u.n) FROM unnest(i.indclass) WITH ORDINALITY u(oid,n) JOIN pg_opclass o ON o.oid=u.oid)
FROM pg_index i WHERE i.indrelid=(SELECT reltoastrelid FROM pg_class WHERE oid='reindex_flags.rows'::regclass);
SELECT 'attributes',a.attnum,a.attname,a.atttypid,a.attnotnull
FROM pg_attribute a WHERE a.attrelid=(SELECT index_oid FROM reindex_flags.before) AND a.attnum>0 ORDER BY a.attnum;
REINDEX TABLE CONCURRENTLY reindex_flags.rows;
SELECT 'after',i.indisunique,i.indisprimary,i.indisvalid,i.indisready,i.indislive,i.indimmediate,
 i.indkey::text,i.indnkeyatts,i.indnatts,i.indcollation::text,
 (SELECT string_agg(o.opcname,',' ORDER BY u.n) FROM unnest(i.indclass) WITH ORDINALITY u(oid,n) JOIN pg_opclass o ON o.oid=u.oid),
 i.indrelid=b.toast_oid,i.indexrelid<>b.index_oid
FROM pg_index i,reindex_flags.before b WHERE i.indrelid=(SELECT reltoastrelid FROM pg_class WHERE oid='reindex_flags.rows'::regclass);
