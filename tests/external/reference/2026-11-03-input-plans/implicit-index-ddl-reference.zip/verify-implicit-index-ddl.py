EXPECTED=['t|t|primary constraint|primary index', 't|t|primary constraint|primary index', '{fillfactor=77}', '{fillfactor=78}', 'implicit_index_exclusion_done|t|t|NULL|NULL', 'implicit_index_primary_done|t|t|primary constraint|primary index', 'implicit_index_unique_done|t|t|NULL|NULL', '3|3']
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert Path(name).name==name and name not in checks
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
assert (root/'planner-drop.sql').read_bytes()==(root/'235_implicit_index_ddl.sql').read_bytes()
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert re.findall(r'ERROR:\s+([A-Z0-9]{5}):',(root/'reference.stderr').read_text())==['42501']
assert 'must be owner of index implicit_index_rows_pkey' in (root/'reference.stderr').read_text()
p=json.loads((root/'provenance.json').read_text());assert p['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert p['observed_error_codes']==['42501'] and checks['235_implicit_index_ddl.sql'] in p['sources'].values()
commands=json.loads((root/'commands.json').read_text());server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(s in server for s in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
print(json.dumps({'verified_files':len(checks),'rows':len(EXPECTED),'error_codes':['42501'],'qualification':'PostgreSQL reference semantics only'}))
