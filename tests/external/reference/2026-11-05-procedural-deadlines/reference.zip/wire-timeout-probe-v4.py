import json
from pathlib import Path
import socket
import struct
import sys
import time

host,port,destination=sys.argv[1:]
port=int(port)
def frame(kind,payload=b''):
 return kind+struct.pack('!I',len(payload)+4)+payload
def exact(connection,count):
 value=b''
 while len(value)<count:
  chunk=connection.recv(count-len(value))
  if not chunk:raise RuntimeError('connection closed')
  value+=chunk
 return value
def receive(connection):
 kind=exact(connection,1);size=struct.unpack('!I',exact(connection,4))[0]
 assert 4<=size<1024*1024
 return kind,exact(connection,size-4)
def until(connection,last):
 output=[]
 while True:
  value=receive(connection);output.append(value)
  if value[0]==last:return output
def query(connection,sql):
 connection.sendall(frame(b'Q',sql.encode()+b'\0'))
 return until(connection,b'Z')
def connect():
 connection=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);connection.settimeout(1)
 connection.connect(f'{host}/.s.PGSQL.{port}')
 payload=struct.pack('!I',196608)+b'user\0postgres\0database\0postgres\0client_encoding\0UTF8\0\0'
 connection.sendall(struct.pack('!I',len(payload)+4)+payload);until(connection,b'Z')
 query(connection,'SET statement_timeout=100')
 return connection
def error_state(payload):
 for field in payload.split(b'\0'):
  if field[:1]==b'C':return field[1:].decode()
 return None
def expire(connection):
 connection.settimeout(.4)
 try:
  while True:
   kind,payload=receive(connection)
   if kind==b'E':return error_state(payload)
 except TimeoutError:return None
 finally:connection.settimeout(1)

def parse(connection):
 connection.sendall(frame(b'P',b's\0SELECT pg_sleep(0.02),7\0'+struct.pack('!H',0))+frame(b'H'))
 until(connection,b'1')
results={}
for mode in ['parse','bind','describe']:
 with connect() as connection:
  parse(connection)
  if mode!='parse':
   connection.sendall(frame(b'S'));until(connection,b'Z')
  if mode=='bind':
   connection.sendall(frame(b'B',b'p\0s\0'+struct.pack('!HHH',0,0,0))+frame(b'H'))
   until(connection,b'2')
  if mode=='describe':
   connection.sendall(frame(b'D',b'Ss\0')+frame(b'H'));until(connection,b'T')
  results[mode+'_idle']=expire(connection)
  if mode!='bind':
   connection.sendall(frame(b'B',b'p\0s\0'+struct.pack('!HHH',0,0,0)))
  connection.sendall(frame(b'E',b'p\0'+struct.pack('!I',0))+frame(b'S'))
  executed=until(connection,b'Z')
  results[mode+'_execute']={'errors':[error_state(payload) for kind,payload in executed if kind==b'E'],'rows':sum(kind==b'D' for kind,payload in executed)}
  assert any(kind==b'D' and b'7' in payload for kind,payload in query(connection,'SELECT 7'))
for mode in ['empty', 'row']:
 with connect() as connection:
  query(connection,f'CREATE TABLE timeout_wire_copy_{mode}(id integer)')
  connection.sendall(frame(b'Q',f'COPY timeout_wire_copy_{mode} FROM STDIN'.encode()+b'\0'));until(connection,b'G')
  results['copy_'+mode+'_idle']=expire(connection)
  if mode=='row':connection.sendall(frame(b'd',b'1\n'))
  connection.sendall(frame(b'c'))
  copied=until(connection,b'Z')
  results['copy_'+mode+'_done']={'errors':[error_state(payload) for kind,payload in copied if kind==b'E']}
Path(destination).write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
assert results['copy_empty_done']['errors']==[]
assert results['copy_row_done']['errors']==['57014']
