SQL_HASH='50968358ef13ff07c244c49fd983b910787a81c72699af6397a9bb7312cd217a'
EXPECTED=['table-changed|1|table|public.owner_event_rows|ALTER TABLE', 'table-unchanged|1|table|public.owner_event_rows|ALTER TABLE', 'view-changed|1|materialized view|public.owner_event_saved|ALTER MATERIALIZED VIEW', 'view-unchanged|1|materialized view|public.owner_event_saved|ALTER MATERIALIZED VIEW']
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert name not in checks and Path(name).name==name
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
assert checks['227_owner_event_commands.sql']==SQL_HASH
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert not re.search(r'ERROR:|FATAL:',(root/'reference.stderr').read_text())
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes']==[]
assert SQL_HASH in provenance['sources'].values()
commands=json.loads((root/'commands.json').read_text())
server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
assert all(re.fullmatch('[0-9a-f]{64}',value) for value in provenance['sources'].values())
print(json.dumps({'verified_files':len(checks),'sql_sha256':SQL_HASH,'output_rows':len(EXPECTED),'qualification':'PostgreSQL reference semantics only'}))
