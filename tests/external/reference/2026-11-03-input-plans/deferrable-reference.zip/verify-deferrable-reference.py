SQL_HASH='993430f12e4e3682a72cb87e05c144398d8a8189b4f1b9951a56c3202f38c86a'
SQL_NAME='223_deferrable_index_identities.sql'
EXPECTED=['before|f', 'after|f|t|t', '2', 'ordinary|f|t|t']
REVISION='5119b065b18405deff619a60a45151fcbdb4fe34 with uncommitted fixture223; exact source hash recorded'
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert name not in checks and Path(name).name==name
    assert re.fullmatch('[0-9a-f]{64}',digest)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
assert checks[SQL_NAME]==SQL_HASH
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert not (root/'reference.stderr').read_text()
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes']==[]
assert provenance['project_revision']==REVISION
assert SQL_HASH in provenance['sources'].values()
for name,digest in provenance['sources'].items():
    assert re.fullmatch('[0-9a-f]{64}',digest)
    copied=root/Path(name).name
    if copied.exists(): assert hashlib.sha256(copied.read_bytes()).hexdigest()==digest
commands=json.loads((root/'commands.json').read_text())
server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
assert any(Path(c[0]).name=='psql' and '--set=VERBOSITY=verbose' in c for c in commands)
print(json.dumps({'verified_files':len(checks),'sql_sha256':SQL_HASH,'output_rows':len(EXPECTED),'qualification':'PostgreSQL reference semantics only; final pos3ql CI required'}))
