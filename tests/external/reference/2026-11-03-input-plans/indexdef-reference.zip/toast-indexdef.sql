CREATE SCHEMA toast_definition;
CREATE TABLE toast_definition.rows(id integer PRIMARY KEY, body text);
SELECT pg_get_indexdef(indexrelid), pg_get_indexdef(indexrelid,1,true),
       pg_get_indexdef(indexrelid,2,true), pg_get_indexdef(indexrelid,3,true)
FROM pg_index WHERE indrelid=(SELECT reltoastrelid FROM pg_class
WHERE oid='toast_definition.rows'::regclass);
REINDEX TABLE CONCURRENTLY toast_definition.rows;
SELECT pg_get_indexdef(indexrelid), pg_get_indexdef(indexrelid,1,true),
       pg_get_indexdef(indexrelid,2,true), pg_get_indexdef(indexrelid,3,true)
FROM pg_index WHERE indrelid=(SELECT reltoastrelid FROM pg_class
WHERE oid='toast_definition.rows'::regclass);
