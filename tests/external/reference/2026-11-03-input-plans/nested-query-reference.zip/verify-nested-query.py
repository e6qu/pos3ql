EXPECTED=["'c' & 'd'", "64|'c' & 'd'", "'a'", "'c' & 'd'", 'kept', '1|one|character varying', '2|two|character varying', '1|one', '2|two', 't|t|key comment|index comment', 't|t|key comment|index comment', 't|t|key comment|index comment', '1|2', '1|2']
ERRORS=['22023', '22023', '22023', '42P01', '22011', '22012']
import hashlib,json,re,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert not Path(name).is_absolute() and '..' not in Path(name).parts and name not in checks
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert set(checks)=={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}-{'SHA256SUMS'}
p=root/'postgres';inner={}
for line in (p/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert Path(name).name==name and name not in inner
 assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
 inner[name]=digest
assert set(inner)=={f.name for f in p.iterdir() if f.is_file()}-{'SHA256SUMS'}
assert (p/'planner-drop.sql').read_bytes()==(p/'234_nested_query_and_index_metadata.sql').read_bytes()
assert (p/'reference.stdout').read_text().splitlines()==EXPECTED
assert re.findall(r'ERROR:\s+([A-Z0-9]{5}):',(p/'reference.stderr').read_text())==ERRORS
provenance=json.loads((p/'provenance.json').read_text());assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes']==ERRORS
assert inner['234_nested_query_and_index_metadata.sql'] in provenance['sources'].values()
commands=json.loads((p/'commands.json').read_text());server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
a=json.loads((root/'crash/artifact.json').read_text());native=root/'crash/historical-native.zip'
assert hashlib.sha256(native.read_bytes()).hexdigest()==a['sha256']
with zipfile.ZipFile(native) as archive:
 assert set(archive.namelist())=={'gdb.txt','harness.patch','harness.patch-stat','llvm-cov.txt','reproduction.log','result.json','rustc.txt'}
 result=json.loads(archive.read('result.json'));log=archive.read('reproduction.log').decode()
 assert result['revision']==a['source_revision']=='8efe894d63eec0cd3ae182c620305384ac3e939f'
 assert result['signals']==['SIGSEGV'] and not result['results'] and result['status']!=0
 assert result['partition']=='lib:0-of-4' and result['stack_bytes']==134217728
 assert result['test_threads'] is None and result['cpu_count']==4
 assert 'running 845 tests' in log
 assert re.search(r'^#0 .*InputAttempt>::update_frame',log,re.M)
 assert re.search(r'^#35 .*full_text_query_rewrite_and_vector_unnest_are_typed',log,re.M)
 assert archive.read('rustc.txt').startswith(b'rustc 1.99.1 ')
 assert archive.read('llvm-cov.txt').strip()==b'cargo-llvm-cov 0.9.1'
 assert b'diff --git a/src/' not in archive.read('harness.patch')
print(json.dumps({'verified_files':len(checks),'postgres_rows':len(EXPECTED),'error_codes':ERRORS,'native_signal':'SIGSEGV','crash_function':'InputAttempt::update_frame','qualification':'Reference semantics and historical failure only; not final-head correctness evidence'}))
