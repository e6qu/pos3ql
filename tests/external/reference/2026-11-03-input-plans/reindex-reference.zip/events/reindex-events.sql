CREATE SCHEMA reindex_events;
CREATE TABLE reindex_events.orders(id integer PRIMARY KEY,code text UNIQUE);
INSERT INTO reindex_events.orders VALUES(1,'a'),(2,'b');
CREATE INDEX orders_plain ON reindex_events.orders(code);
CREATE TABLE reindex_events.before AS
 SELECT c.oid AS index_oid,c.relname,k.oid AS constraint_oid
 FROM pg_class c LEFT JOIN pg_constraint k ON k.conindid=c.oid
 WHERE c.relnamespace='reindex_events'::regnamespace AND c.relkind='i';
CREATE TABLE reindex_events.context(stage text);
INSERT INTO reindex_events.context VALUES('setup');
CREATE TABLE reindex_events.events(stage text,kind text,tag text,object_type text,identity text,classid oid,objid oid);
CREATE FUNCTION reindex_events.collect_end() RETURNS event_trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO reindex_events.events
 SELECT x.stage,'end',d.command_tag,d.object_type,d.object_identity,d.classid,d.objid
 FROM reindex_events.context x,pg_event_trigger_ddl_commands() d;
END$$;
CREATE FUNCTION reindex_events.collect_drop() RETURNS event_trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO reindex_events.events
 SELECT x.stage,'drop',TG_TAG,d.object_type,d.object_identity,d.classid,d.objid
 FROM reindex_events.context x,pg_event_trigger_dropped_objects() d;
END$$;
CREATE FUNCTION reindex_events.collect_start() RETURNS event_trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO reindex_events.events
 SELECT x.stage,'start',TG_TAG,NULL,NULL,NULL,NULL FROM reindex_events.context x;
END$$;
CREATE EVENT TRIGGER reindex_end ON ddl_command_end EXECUTE FUNCTION reindex_events.collect_end();
CREATE EVENT TRIGGER reindex_drop ON sql_drop EXECUTE FUNCTION reindex_events.collect_drop();
CREATE EVENT TRIGGER reindex_start ON ddl_command_start EXECUTE FUNCTION reindex_events.collect_start();
DELETE FROM reindex_events.events;
UPDATE reindex_events.context SET stage='primary';
REINDEX INDEX CONCURRENTLY reindex_events.orders_pkey;
SELECT e.stage,e.kind,e.tag,e.object_type,e.identity,
 e.objid=c.oid AS selected_current_index,e.objid=b.index_oid AS selected_old_index
FROM reindex_events.events e
LEFT JOIN pg_class c ON c.relnamespace='reindex_events'::regnamespace AND c.relname='orders_pkey'
LEFT JOIN reindex_events.before b ON b.relname='orders_pkey'
ORDER BY e.kind,e.identity;
SELECT 'primary_constraint',k.oid=b.constraint_oid,k.conindid='reindex_events.orders_pkey'::regclass
FROM pg_constraint k JOIN reindex_events.before b ON k.conname=b.relname WHERE b.relname='orders_pkey';
DELETE FROM reindex_events.events;
TRUNCATE reindex_events.before;
INSERT INTO reindex_events.before
 SELECT c.oid,c.relname,k.oid FROM pg_class c LEFT JOIN pg_constraint k ON k.conindid=c.oid
 WHERE c.relnamespace='reindex_events'::regnamespace AND c.relkind='i';
UPDATE reindex_events.context SET stage='table';
REINDEX TABLE CONCURRENTLY reindex_events.orders;
SELECT e.stage,e.kind,e.tag,e.object_type,e.identity,
 e.objid=c.oid AS selected_current_index,e.objid=b.index_oid AS selected_old_index
FROM reindex_events.events e
LEFT JOIN pg_class c ON c.oid=e.objid
LEFT JOIN reindex_events.before b ON e.identity='reindex_events.'||b.relname
ORDER BY e.kind,e.identity;
SELECT 'table_constraints',count(*),bool_and(k.oid=b.constraint_oid AND k.conindid=c.oid)
FROM pg_class c JOIN reindex_events.before b ON b.relname=c.relname
JOIN pg_constraint k ON k.conindid=c.oid WHERE c.relnamespace='reindex_events'::regnamespace;
SELECT 'table_drop_events',count(*) FROM reindex_events.events WHERE kind='drop';
