CREATE SCHEMA reindex_reference;
CREATE TABLE reindex_reference.orders(id integer PRIMARY KEY,code text UNIQUE);
INSERT INTO reindex_reference.orders VALUES(1,'a'),(2,'b');
CREATE INDEX orders_plain ON reindex_reference.orders(code);
COMMENT ON CONSTRAINT orders_pkey ON reindex_reference.orders IS 'constraint comment';
COMMENT ON INDEX reindex_reference.orders_pkey IS 'index comment';
CREATE TEMP TABLE index_before AS
  SELECT c.oid AS index_oid,c.relname,k.oid AS constraint_oid
  FROM pg_class c LEFT JOIN pg_constraint k ON k.conindid=c.oid
  WHERE c.relnamespace='reindex_reference'::regnamespace AND c.relkind='i';
REINDEX INDEX CONCURRENTLY reindex_reference.orders_pkey;
SELECT 'primary',c.oid<>b.index_oid,k.oid=b.constraint_oid,k.conindid=c.oid,
  obj_description(k.oid,'pg_constraint'),obj_description(c.oid,'pg_class')
FROM pg_class c JOIN index_before b ON b.relname=c.relname
JOIN pg_constraint k ON k.conindid=c.oid
WHERE c.oid='reindex_reference.orders_pkey'::regclass;
SELECT 'old_primary_removed',count(*) FROM pg_class c JOIN index_before b ON b.index_oid=c.oid WHERE b.relname='orders_pkey';
REINDEX TABLE CONCURRENTLY reindex_reference.orders;
SELECT 'table',c.relname,c.oid<>b.index_oid,
  CASE WHEN b.constraint_oid IS NULL THEN true ELSE k.oid=b.constraint_oid END
FROM pg_class c JOIN index_before b ON b.relname=c.relname
LEFT JOIN pg_constraint k ON k.conindid=c.oid
WHERE c.relnamespace='reindex_reference'::regnamespace ORDER BY c.relname;
SELECT 'temporary_names',count(*) FROM pg_class WHERE relnamespace='reindex_reference'::regnamespace AND (relname LIKE '%ccnew%' OR relname LIKE '%ccold%');
CREATE TABLE reindex_reference.ranges(value int4range,EXCLUDE USING gist(value WITH &&));
INSERT INTO reindex_reference.ranges VALUES('[1,2)');
CREATE TEMP TABLE exclusion_before AS SELECT oid FROM pg_class WHERE oid='reindex_reference.ranges_value_excl'::regclass;
REINDEX INDEX CONCURRENTLY reindex_reference.ranges_value_excl;
SELECT 'direct_exclusion_same',c.oid=b.oid FROM pg_class c,exclusion_before b WHERE c.oid='reindex_reference.ranges_value_excl'::regclass;
REINDEX TABLE CONCURRENTLY reindex_reference.ranges;
SELECT 'table_exclusion_same',c.oid=b.oid FROM pg_class c,exclusion_before b WHERE c.oid='reindex_reference.ranges_value_excl'::regclass;
CREATE TABLE reindex_reference.parts(id integer PRIMARY KEY) PARTITION BY RANGE(id);
CREATE TABLE reindex_reference.parts_low PARTITION OF reindex_reference.parts FOR VALUES FROM(0) TO(10);
CREATE TABLE reindex_reference.parts_high PARTITION OF reindex_reference.parts FOR VALUES FROM(10) TO(20);
INSERT INTO reindex_reference.parts VALUES(1),(11);
CREATE TEMP TABLE partition_before AS
 SELECT c.oid AS index_oid,c.relname,c.relkind,k.oid AS constraint_oid
 FROM pg_class c JOIN pg_constraint k ON k.conindid=c.oid
 WHERE c.relnamespace='reindex_reference'::regnamespace AND c.relname LIKE 'parts%';
REINDEX INDEX CONCURRENTLY reindex_reference.parts_pkey;
SELECT 'partition',c.relname,c.oid<>b.index_oid,k.oid=b.constraint_oid
FROM pg_class c JOIN partition_before b ON b.relname=c.relname
JOIN pg_constraint k ON k.conindid=c.oid
WHERE c.relnamespace='reindex_reference'::regnamespace ORDER BY c.relname;
CREATE TEMP TABLE temp_rows(id integer);
CREATE INDEX temp_rows_idx ON temp_rows(id);
CREATE TEMP TABLE temp_before AS SELECT oid FROM pg_class WHERE oid='temp_rows_idx'::regclass;
REINDEX INDEX CONCURRENTLY temp_rows_idx;
SELECT 'temp_same_index',c.oid=b.oid FROM pg_class c,temp_before b WHERE c.oid='temp_rows_idx'::regclass;
REINDEX SYSTEM CONCURRENTLY postgres;
