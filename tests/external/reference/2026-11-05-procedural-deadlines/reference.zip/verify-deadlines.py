import hashlib
import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
for entry in (root / "SHA256SUMS").read_text().splitlines():
    expected, name = entry.split("  ", 1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
assert (root / "reference.stdout").read_text().splitlines() == ["caught", "after", "0"]
errors = re.findall(r"ERROR:\s+([A-Z0-9]{5}):", (root / "reference.stderr").read_text())
assert errors == ["57014", "57014"], errors
observed = json.loads((root / "wire-results.json").read_text())
for mode in ["parse", "bind", "describe"]:
    assert observed[mode + "_idle"] is None
    assert observed[mode + "_execute"] == {"errors": ["57014"], "rows": 0}
assert observed["copy_empty_idle"] is None
assert observed["copy_row_idle"] is None
assert observed["copy_empty_done"] == {"errors": []}
assert observed["copy_row_done"] == {"errors": ["57014"]}
assert observed["copy_trigger_handler_rows"] == ["8", "2"]
provenance = json.loads((root / "provenance.json").read_text())
assert "18.6" in provenance["version"]
assert provenance["purpose"] == "reference SQL semantics; no pos3ql execution or performance qualification"
for source, expected in provenance["sources"].items():
    local = root / Path(source).name
    if local.exists():
        assert hashlib.sha256(local.read_bytes()).hexdigest() == expected, source
commands = json.loads((root / "commands.json").read_text())
assert any("shared_buffers=16MB" in command and "work_mem=1MB" in command and "max_connections=5" in command and "listen_addresses=" in command for command in commands)
print("PostgreSQL deadline and COPY handler reference: hashes and results verified")
