import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import socket
import struct
import subprocess
import tempfile
import time

root = Path(__file__).resolve().parent
output = root / "reindex-writer-reference"
output.mkdir(exist_ok=False)
prefix = Path("/opt/homebrew/opt/postgresql@18/bin")
environment = {key: value for key, value in os.environ.items() if not key.startswith("PG")}
environment.update({"LC_ALL": "C", "LANG": "C"})
commands = []
transcript = []


def run(arguments, **options):
    commands.append([str(value) for value in arguments])
    return subprocess.run(arguments, env=environment, check=True, text=True, **options)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frontend(kind, payload=b""):
    return kind + struct.pack("!I", len(payload) + 4) + payload


def exact(connection, size):
    result = b""
    while len(result) < size:
        part = connection.recv(size - len(result))
        if not part:
            raise EOFError("reference connection closed")
        result += part
    return result


def exchange(connection, label, message, terminal):
    if message[:1] in {b"P", b"B", b"E", b"C"}:
        message += frontend(b"H")
    connection.sendall(message)
    responses = []
    while True:
        kind = exact(connection, 1)
        size = struct.unpack("!I", exact(connection, 4))[0]
        payload = exact(connection, size - 4)
        responses.append((kind, payload))
        if kind in terminal:
            break
    transcript.append({"label": label, "request_hex":message.hex(), "messages": [(kind.decode(), payload.hex()) for kind, payload in responses if kind != b"K"]})
    return responses


def query(connection, label, sql):
    return exchange(connection, label, frontend(b"Q", sql.encode() + b"\0"), {b"Z"})


def parse(connection, label, sql, name=""):
    return exchange(connection, label, frontend(b"P", name.encode() + b"\0" + sql.encode() + b"\0\0\0"), {b"1", b"E"})


def bind(connection, label, name="", portal="", parameter=None):
    payload = portal.encode() + b"\0" + name.encode() + b"\0\0\0"
    if parameter is None:
        payload += b"\0\0"
    else:
        value = parameter.encode()
        payload += struct.pack("!hI", 1, len(value)) + value
    return exchange(connection, label, frontend(b"B", payload + b"\0\0"), {b"2", b"E"})


def execute(connection, label, portal=""):
    return exchange(connection, label, frontend(b"E", portal.encode() + b"\0" + bytes(4)), {b"C", b"E"})


def sync(connection, label):
    return exchange(connection, label, frontend(b"S"), {b"Z"})


def first_row(messages):
    payload = next(payload for kind, payload in messages if kind == b"D")
    size = struct.unpack("!i", payload[2:6])[0]
    return payload[6:6 + size].decode()


version = run([prefix / "postgres", "--version"], capture_output=True).stdout.strip()
assert version == "postgres (PostgreSQL) 18.6 (Homebrew)", version
provenance = {"time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "version": version, "platform": platform.platform(),
              "project_revision": "82c3d71db2b420582a893acf111fd3ec81e93d7c", "guard": "/Users/zardoz/.codex/tools/fr-local-guard.py",
              "purpose": "PostgreSQL reindex registration before writer waits and cancellation reference; no pos3ql execution",
              "omitted_fields": ["startup BackendKeyData cancel identifiers"],
              "sources": {str(path): digest(path) for path in [Path(__file__), prefix / "postgres", prefix / "initdb"]}}
try:
    with tempfile.TemporaryDirectory(prefix="p3-protocol-", dir="/private/tmp") as directory:
        temporary = Path(directory)
        data = temporary / "data"
        sockets = temporary / "sockets"
        sockets.mkdir(mode=0o700)
        with (output / "initdb.stdout").open("w") as stdout, (output / "initdb.stderr").open("w") as stderr:
            run([prefix / "initdb", "--pgdata", data, "--username=postgres", "--auth=trust", "--encoding=UTF8", "--locale=C", "--no-sync"], stdout=stdout, stderr=stderr)
        arguments = [str(prefix / "postgres"), "-D", str(data), "-k", str(sockets), "-p", "56379"]
        for setting in ["listen_addresses=", "shared_buffers=16MB", "wal_buffers=1MB", "work_mem=1MB", "maintenance_work_mem=8MB", "temp_buffers=1MB", "max_connections=5", "superuser_reserved_connections=1", "autovacuum=off", "max_worker_processes=0", "max_wal_senders=0", "wal_level=minimal", "fsync=off", "full_page_writes=off", "synchronous_commit=off", "max_wal_size=64MB", "min_wal_size=32MB", "timezone=UTC"]:
            arguments.extend(["-c", setting])
        commands.append(arguments)
        with (output / "server.log").open("w") as log:
            server = subprocess.Popen(arguments, env=environment, stdout=log, stderr=subprocess.STDOUT)
            connections = []
            try:
                deadline = time.monotonic() + 20
                while not (sockets / ".s.PGSQL.56379").exists():
                    if server.poll() is not None or time.monotonic() >= deadline:
                        raise RuntimeError("PostgreSQL reference did not become ready")
                    time.sleep(0.05)
                for index in range(3):
                    connection = socket.socket(socket.AF_UNIX)
                    connection.settimeout(10)
                    connection.connect(str(sockets / ".s.PGSQL.56379"))
                    connections.append(connection)
                    startup = struct.pack("!I", 196608) + b"user\0postgres\0database\0postgres\0\0"
                    exchange(connection, f"startup-{index}", struct.pack("!I", len(startup) + 4) + startup, {b"Z"})
                builder,writer,observer=connections
                pid=first_row(query(builder,'builder-pid','SELECT pg_backend_pid()'))
                for suffix,key,immediate in [('ordinary','PRIMARY KEY','true'),('deferred','PRIMARY KEY DEFERRABLE INITIALLY DEFERRED','false')]:
                    table='writer_reindex_'+suffix
                    index=table+'_pkey'
                    query(builder,'setup-'+suffix,f'CREATE TABLE {table}(id integer {key}); INSERT INTO {table} VALUES(1)')
                    original=first_row(query(observer,'original-'+suffix,f"SELECT conindid FROM pg_constraint WHERE conname='{index}'"))
                    query(writer,'writer-begin-'+suffix,f'BEGIN; INSERT INTO {table} VALUES(2)')
                    sql=f'REINDEX INDEX CONCURRENTLY {index}'
                    request=frontend(b'Q',sql.encode()+b'\0')
                    transcript.append({'label':'begin-reindex-'+suffix,'request_hex':request.hex(),'messages':[]})
                    builder.sendall(request)
                    deadline=time.monotonic()+3
                    while True:
                        snapshot=query(observer,'registered-'+suffix,f"SELECT i.indisvalid::text||':'||i.indisready::text||':'||i.indislive::text||':'||i.indimmediate::text FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid WHERE c.relname='{index}_ccnew'")
                        if any(kind==b'D' for kind,payload in snapshot):break
                        if time.monotonic()>=deadline:raise RuntimeError('replacement did not publish before writer wait')
                        time.sleep(.05)
                    assert first_row(snapshot)=='false:false:true:'+immediate, snapshot
                    assert first_row(query(observer,'constraint-before-cancel-'+suffix,f"SELECT conindid FROM pg_constraint WHERE conname='{index}'"))==original
                    assert first_row(query(observer,'cancel-'+suffix,'SELECT pg_cancel_backend('+pid+')'))=='t'
                    cancelled=exchange(builder,'cancel-result-'+suffix,b'',{b'Z'})
                    assert any(kind==b'E' and b'C57014\0' in payload for kind,payload in cancelled),cancelled
                    query(writer,'writer-commit-'+suffix,'COMMIT')
                    assert first_row(query(observer,'constraint-after-cancel-'+suffix,f"SELECT conindid FROM pg_constraint WHERE conname='{index}'"))==original
                    assert first_row(query(observer,'replacement-after-cancel-'+suffix,f"SELECT count(*) FROM pg_class WHERE relname='{index}_ccnew'"))=='1'
                    query(builder,'drop-failed-'+suffix,f'DROP INDEX {index}_ccnew')
                    query(builder,'rebuild-'+suffix,f'REINDEX INDEX CONCURRENTLY {index}')
                    assert first_row(query(observer,'replaced-'+suffix,f"SELECT conindid<>{original} FROM pg_constraint WHERE conname='{index}'"))=='t'
                    query(builder,'drop-'+suffix,f'DROP TABLE {table}')
            finally:
                for connection in connections:
                    connection.close()
                if server.poll() is None:
                    server.send_signal(signal.SIGINT)
                    try:
                        server.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait()
    print(json.dumps({"version": version, "transcript_entries": len(transcript)}, indent=2))
finally:
    (output / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    (output / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
    (output / "transcript.json").write_text(json.dumps(transcript, indent=2) + "\n")
    (output / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    (output / "SHA256SUMS").write_text("".join(f"{digest(path)}  {path.name}\n" for path in sorted(output.iterdir()) if path.is_file() and path.name != "SHA256SUMS"))
