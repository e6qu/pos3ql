import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    path=Path(name)
    assert name not in checks and not path.is_absolute() and '..' not in path.parts
    assert re.fullmatch('[0-9a-f]{64}',digest)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    checks[name]=digest
assert set(checks)=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}-{'SHA256SUMS'}
expected={
'eligibility': ['primary|t|t|t|constraint comment|index comment','old_primary_removed|0','table|orders_code_key|t|t','table|orders_pkey|t|t','table|orders_plain|t|t','temporary_names|0','direct_exclusion_same|t','table_exclusion_same|t','partition|parts_high_pkey|t|t','partition|parts_low_pkey|t|t','partition|parts_pkey|f|t','temp_same_index|t'],
'events': ['primary|end|REINDEX|index|reindex_events.orders_pkey|t|f','primary|start|REINDEX||||','primary_constraint|t|t',None,'table|end|REINDEX|index|reindex_events.orders_code_key|t|f','table|end|REINDEX|index|reindex_events.orders_pkey|t|f','table|end|REINDEX|index|reindex_events.orders_plain|t|f','table|start|REINDEX||||','table_constraints|2|t','table_drop_events|0'],
 'toast': ['toast_identity|t|t','direct_toast|end|REINDEX|index|toast_index|t|f','direct_toast|start|REINDEX||||','direct_toast_drop_events|0'],
 'toast-flags': ['before|t|t|t|t|t|t|1 2|2|2|0 0|oid_ops,int4_ops','attributes|1|chunk_id|26|f','attributes|2|chunk_seq|23|f','after|t|t|t|t|t|t|1 2|2|2|0 0|oid_ops,int4_ops|t|t'],
 'toast-dependencies': ['before|pg_class|index|0|pg_class|toast|1|a','before|pg_class|index|0|pg_class|toast|2|a','before|pg_class|toast|0|pg_class|owner|0|i','after|pg_class|index|0|pg_class|toast|1|a','after|pg_class|index|0|pg_class|toast|2|a','after|pg_class|toast|0|pg_class|owner|0|i'],
 'invalid': ['failed_build|t|f|f|f|t','table|t|t|f|f|f|t','direct|t|t|f|t|t|t','old_removed|0']}
sql_hashes={'eligibility': 'b61c88a81512aaf39bd579cce9a7e2e111aec24c9b8349722bf7f0f684f31b4f', 'events': '83d68c5c53183828f67c4c7d4877ca1187e3e0f0712e9c3de0c90be53da5e63c', 'toast': 'b751b0d0f84eac301bddf8f003ff3c525b6e14034668b55a40511651ba0b95ae', 'toast-flags': '609cee73c121c1c591abecdbadc28c56225d867dc320224de84a149f38cb2623', 'toast-dependencies': '7905bf29d52a6c28409780e53ba08b5851e2cadaf5ced913ab95cbf8af0fb7f4', 'invalid': '278f2159aaf370335fe579ad4160867b9be09e845001d964ae3f6422d2c20f14'}
for probe,rows in expected.items():
    directory=root/probe
    assert hashlib.sha256((directory/f'reindex-{probe}.sql').read_bytes()).hexdigest()==sql_hashes[probe]
    actual=(directory/'reference.stdout').read_text().splitlines()
    assert len(actual)==len(rows),(probe,actual)
    for index,(actual_row,expected_row) in enumerate(zip(actual,rows)):
        if expected_row is None:
            assert re.fullmatch(r'table\|end\|REINDEX\|index\|pg_toast\.pg_toast_[0-9]+_index\|t\|',actual_row),actual_row
        else:
            assert actual_row==expected_row,(probe,index,actual_row)
    stderr=(directory/'reference.stderr').read_text()
    codes=re.findall(r'ERROR:\s+([A-Z0-9]{5}):',stderr)
    assert codes==({'eligibility':['0A000','0A000'],'invalid':['23505']}.get(probe,[])),(probe,codes)
    assert 'FATAL:' not in stderr
    if probe=='eligibility':
        assert 'concurrent index creation for exclusion constraints is not supported' in stderr
        assert 'cannot reindex system catalogs concurrently' in stderr
        assert re.findall(r'WARNING:\s+([A-Z0-9]{5}):',stderr)==['0A000']
        assert 'cannot reindex exclusion constraint index "reindex_reference.ranges_value_excl" concurrently, skipping' in stderr
    if probe=='invalid':
        assert re.findall(r'WARNING:\s+([A-Z0-9]{5}):',stderr)==['55000']
        assert 'skipping reindex of invalid index \"reindex_invalid.rows_unique\"' in stderr
        assert 'Use DROP INDEX or REINDEX INDEX.' in stderr
        assert 'NOTICE:  00000: table \"rows\" has no indexes that can be reindexed concurrently' in stderr
    provenance=json.loads((directory/'provenance.json').read_text())
    assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
    assert provenance['observed_error_codes']==codes
    assert provenance['project_revision'].startswith('5119b065b18405deff619a60a45151fcbdb4fe34;')
    assert all(re.fullmatch('[0-9a-f]{64}',value) for value in provenance['sources'].values())
    for name,digest in provenance['sources'].items():
        local=directory/Path(name).name
        if local.exists(): assert hashlib.sha256(local.read_bytes()).hexdigest()==digest
    commands=json.loads((directory/'commands.json').read_text())
    server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
    assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
    assert any(Path(c[0]).name=='psql' and '--set=VERBOSITY=verbose' in c for c in commands)
print(json.dumps({'verified_files':len(checks),'sql_sha256':sql_hashes,'eligibility_rows':12,'event_rows':10,'direct_toast_rows':4,'toast_flag_rows':4,'toast_dependency_rows':6,'invalid_rows':4,'qualification':'PostgreSQL reference semantics only; no pos3ql execution or performance qualification'}))
