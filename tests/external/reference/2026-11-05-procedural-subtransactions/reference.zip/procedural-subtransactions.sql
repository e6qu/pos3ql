-- Caught errors keep procedural variables and sequence effects, while undoing
-- data, schema and settings changed inside the failed block.
CREATE TABLE subtx_values(id integer PRIMARY KEY, value integer);
INSERT INTO subtx_values VALUES (1,10),(2,20),(3,30);
CREATE TABLE subtx_notes(label text, value text);
CREATE SEQUENCE subtx_attempts;
SET application_name = 'kept';
SET DateStyle = 'ISO, MDY';
CREATE FUNCTION subtx_restore() RETURNS integer LANGUAGE plpgsql AS $$
DECLARE kept integer := 1;
BEGIN
  BEGIN
    kept := 9;
    PERFORM nextval('subtx_attempts');
    PERFORM set_config('application_name','discarded',false);
    PERFORM set_config('DateStyle','SQL, DMY',true);
    CREATE TABLE subtx_discarded(id integer PRIMARY KEY);
    ALTER TABLE subtx_values ADD COLUMN discarded integer;
    CREATE INDEX subtx_discarded_index ON subtx_values(value);
    INSERT INTO subtx_values(id,value) VALUES (4,40);
    RAISE EXCEPTION 'undo this block';
  EXCEPTION WHEN raise_exception THEN
    INSERT INTO subtx_notes VALUES
      ('handler',kept::text || ':' || current_setting('application_name') || ':' || current_setting('DateStyle'));
  END;
  RETURN kept;
END$$;
SELECT subtx_restore();
SELECT label,value FROM subtx_notes ORDER BY label;
SELECT count(*),sum(value) FROM subtx_values;
SELECT to_regclass('subtx_discarded') IS NULL,
       to_regclass('subtx_discarded_index') IS NULL,
       NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid='subtx_values'::regclass AND attname='discarded' AND NOT attisdropped);
SELECT last_value,is_called FROM subtx_attempts;

-- A caught DROP must restore the existing relation and its stored data.
DO $$BEGIN
  BEGIN
    DROP TABLE subtx_values;
    RAISE EXCEPTION 'restore the table';
  EXCEPTION WHEN raise_exception THEN
    INSERT INTO subtx_notes VALUES ('drop', (SELECT sum(value)::text FROM subtx_values));
  END;
END$$;
SELECT label,value FROM subtx_notes WHERE label='drop';

-- Nested exception blocks must not consume or replace the client's savepoint.
BEGIN;
SAVEPOINT client_boundary;
DO $$BEGIN
  PERFORM set_config('application_name','outer',false);
  BEGIN
    PERFORM set_config('application_name','inner',false);
    BEGIN
      PERFORM set_config('application_name','deep',false);
      RAISE EXCEPTION 'deep failure';
    EXCEPTION WHEN raise_exception THEN
      INSERT INTO subtx_notes VALUES ('deep',current_setting('application_name'));
    END;
    RAISE EXCEPTION 'inner failure';
  EXCEPTION WHEN raise_exception THEN
    INSERT INTO subtx_notes VALUES ('inner',current_setting('application_name'));
  END;
END$$;
SELECT label,value FROM subtx_notes WHERE label IN ('deep','inner') ORDER BY label;
ROLLBACK TO client_boundary;
SELECT current_setting('application_name'),count(*) FROM subtx_notes WHERE label IN ('deep','inner');
RELEASE client_boundary;
COMMIT;

-- Aborted rows must leave no queued deferred trigger, even after many catches.
CREATE TABLE subtx_deferred(id integer);
CREATE TABLE subtx_delivered(id integer);
CREATE FUNCTION subtx_deliver() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN INSERT INTO subtx_delivered VALUES (NEW.id); RETURN NEW; END$$;
CREATE CONSTRAINT TRIGGER subtx_deliver AFTER INSERT ON subtx_deferred
DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION subtx_deliver();
BEGIN;
DO $$BEGIN
  FOR attempt IN 1..64 LOOP
    BEGIN
      INSERT INTO subtx_deferred VALUES (-attempt);
      RAISE EXCEPTION 'discard the queued event';
    EXCEPTION WHEN raise_exception THEN NULL;
    END;
  END LOOP;
END$$;
INSERT INTO subtx_deferred VALUES (7);
COMMIT;
SELECT id FROM subtx_deferred ORDER BY id;
SELECT id FROM subtx_delivered ORDER BY id;

-- Cursor creation rolls back, but motion of an older cursor does not.
BEGIN;
DECLARE subtx_old NO SCROLL CURSOR FOR SELECT id FROM subtx_values ORDER BY id;
SAVEPOINT cursor_boundary;
DECLARE subtx_new CURSOR FOR SELECT 41;
FETCH NEXT FROM subtx_old;
CLOSE subtx_new;
DECLARE subtx_new CURSOR FOR SELECT 42;
ROLLBACK TO cursor_boundary;
SELECT name FROM pg_cursors WHERE name IN ('subtx_old','subtx_new') ORDER BY name;
FETCH NEXT FROM subtx_old;
RELEASE cursor_boundary;
COMMIT;

-- A procedural cursor name remains in its variable after its portal is undone.
CREATE FUNCTION subtx_cursor() RETURNS integer LANGUAGE plpgsql AS $$
DECLARE selected refcursor := 'subtx_procedural'; answer integer;
BEGIN
  BEGIN
    OPEN selected FOR SELECT 11;
    RAISE EXCEPTION 'close the new cursor';
  EXCEPTION WHEN raise_exception THEN
    OPEN selected FOR SELECT 12;
  END;
  FETCH selected INTO answer;
  CLOSE selected;
  RETURN answer;
END$$;
SELECT subtx_cursor();
SELECT current_setting('application_name'),current_setting('DateStyle');


CREATE TABLE savepoint_cursor_rows(id integer);
INSERT INTO savepoint_cursor_rows VALUES(1),(2);
BEGIN;
DECLARE old_cursor NO SCROLL CURSOR FOR SELECT 100/(id-1) FROM savepoint_cursor_rows;
SAVEPOINT cursor_boundary;
DECLARE new_cursor NO SCROLL CURSOR FOR SELECT 100/(id-1) FROM savepoint_cursor_rows;
-- error: 22012
FETCH NEXT FROM new_cursor;
ROLLBACK TO cursor_boundary;
SELECT name FROM pg_cursors ORDER BY name;
DECLARE new_cursor CURSOR FOR SELECT 7;
FETCH NEXT FROM new_cursor;
ROLLBACK TO cursor_boundary;
-- error: 22012
FETCH NEXT FROM old_cursor;
ROLLBACK TO cursor_boundary;
-- error: 55000
FETCH NEXT FROM old_cursor;
ROLLBACK TO cursor_boundary;
CLOSE old_cursor;
ROLLBACK TO cursor_boundary;
SELECT count(*) FROM pg_cursors;
COMMIT;


BEGIN;
CREATE TABLE subtx_durable(id integer PRIMARY KEY);
INSERT INTO subtx_durable VALUES(1);
DO $$BEGIN
  BEGIN
    ALTER TABLE subtx_durable ADD COLUMN discarded integer;
    CREATE TABLE subtx_not_durable(id integer);
    INSERT INTO subtx_durable(id) VALUES(2);
    RAISE EXCEPTION 'discard changes';
  EXCEPTION WHEN raise_exception THEN
    INSERT INTO subtx_durable VALUES(3);
  END;
END$$;
COMMIT;
SELECT id FROM subtx_durable ORDER BY id;
SELECT to_regclass('subtx_not_durable') IS NULL,
       NOT EXISTS(SELECT 1 FROM pg_attribute WHERE attrelid='subtx_durable'::regclass AND attname='discarded' AND NOT attisdropped);


CREATE TABLE trigger_subtx_source(id integer PRIMARY KEY);
CREATE TABLE trigger_subtx_notes(kind text,id integer,seen text);
CREATE TABLE trigger_subtx_pending(id integer);
CREATE TABLE trigger_subtx_delivered(id integer);
SET application_name = 'kept';
CREATE FUNCTION trigger_subtx_deliver() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN INSERT INTO trigger_subtx_delivered VALUES(NEW.id); RETURN NEW; END$$;
CREATE CONSTRAINT TRIGGER trigger_subtx_deliver AFTER INSERT ON trigger_subtx_pending
DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION trigger_subtx_deliver();
CREATE FUNCTION trigger_subtx_before() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    INSERT INTO trigger_subtx_notes VALUES('discarded',NEW.id,'before');
    PERFORM set_config('application_name','discarded-before',false);
    NEW.id := NEW.id + 10;
    RAISE EXCEPTION 'keep NEW but undo the writes';
  EXCEPTION WHEN raise_exception THEN
    INSERT INTO trigger_subtx_notes VALUES('before',NEW.id,current_setting('application_name'));
  END;
  RETURN NEW;
END$$;
CREATE FUNCTION trigger_subtx_after() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    INSERT INTO trigger_subtx_pending VALUES(NEW.id);
    PERFORM set_config('application_name','discarded-after',false);
    RAISE EXCEPTION 'discard the deferred event';
  EXCEPTION WHEN raise_exception THEN
    INSERT INTO trigger_subtx_notes VALUES('after',NEW.id,current_setting('application_name'));
  END;
  RETURN NEW;
END$$;
CREATE FUNCTION trigger_subtx_statement() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    INSERT INTO trigger_subtx_pending SELECT id FROM inserted;
    PERFORM set_config('application_name','discarded-statement',false);
    RAISE EXCEPTION 'keep transition rows but undo their writes';
  EXCEPTION WHEN raise_exception THEN
    INSERT INTO trigger_subtx_notes SELECT 'statement',count(*)::integer,current_setting('application_name') FROM inserted;
  END;
  RETURN NULL;
END$$;
CREATE TRIGGER trigger_subtx_before BEFORE INSERT ON trigger_subtx_source
FOR EACH ROW EXECUTE FUNCTION trigger_subtx_before();
CREATE TRIGGER trigger_subtx_after AFTER INSERT ON trigger_subtx_source
FOR EACH ROW EXECUTE FUNCTION trigger_subtx_after();
CREATE TRIGGER trigger_subtx_statement AFTER INSERT ON trigger_subtx_source
REFERENCING NEW TABLE AS inserted FOR EACH STATEMENT EXECUTE FUNCTION trigger_subtx_statement();
BEGIN;
INSERT INTO trigger_subtx_source VALUES(1),(2);
INSERT INTO trigger_subtx_pending VALUES(99);
COMMIT;
SELECT id FROM trigger_subtx_source ORDER BY id;
SELECT kind,id,seen FROM trigger_subtx_notes ORDER BY kind,id;
SELECT id FROM trigger_subtx_pending ORDER BY id;
SELECT id FROM trigger_subtx_delivered ORDER BY id;
SELECT current_setting('application_name');


CREATE ROLE subtx_other_user;
CREATE ROLE subtx_definer_owner;
CREATE TABLE subtx_identity_before AS SELECT session_user AS login,current_user AS role_name;
GRANT SELECT ON subtx_identity_before TO subtx_definer_owner;
SET application_name = 'kept';
CREATE FUNCTION subtx_auth_identity() RETURNS boolean LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    SET SESSION AUTHORIZATION subtx_other_user;
    RAISE EXCEPTION 'restore session authorization';
  EXCEPTION WHEN raise_exception THEN
    RETURN session_user=(SELECT login FROM subtx_identity_before)
       AND current_user=(SELECT role_name FROM subtx_identity_before);
  END;
END$$;
SELECT subtx_auth_identity();
SELECT session_user=login,current_user=role_name FROM subtx_identity_before;
CREATE FUNCTION subtx_definer_identity() RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  BEGIN
    PERFORM set_config('application_name','discarded-definer',false);
    RAISE EXCEPTION 'restore settings inside the owner scope';
  EXCEPTION WHEN raise_exception THEN
    RETURN current_user='subtx_definer_owner'
       AND session_user=(SELECT login FROM subtx_identity_before)
       AND current_setting('application_name')='kept';
  END;
END$$;
ALTER FUNCTION subtx_definer_identity() OWNER TO subtx_definer_owner;
SELECT subtx_definer_identity();
SELECT session_user=login,current_user=role_name,current_setting('application_name')='kept'
FROM subtx_identity_before;


CREATE TABLE pos3ql_fdw_source(id integer,note text);


-- The first foreign connection can open inside the failed block. Nested
-- catches must mirror its transaction boundaries without losing the outer row.
BEGIN;
SAVEPOINT outside_procedure;
DO $$BEGIN
  BEGIN
    INSERT INTO pos3ql_fdw_source(id,note) VALUES(1001,'discarded first connection');
    RAISE EXCEPTION 'discard remote insert';
  EXCEPTION WHEN raise_exception THEN
    INSERT INTO pos3ql_fdw_source(id,note) VALUES(1002,'kept handler');
  END;
  BEGIN
    UPDATE pos3ql_fdw_source SET note='discarded outer change' WHERE id=1002;
    BEGIN
      DELETE FROM pos3ql_fdw_source WHERE id=1002;
      RAISE EXCEPTION 'restore remote delete';
    EXCEPTION WHEN raise_exception THEN
      INSERT INTO pos3ql_fdw_source(id,note) VALUES(1003,'discarded nested handler');
    END;
    RAISE EXCEPTION 'discard the enclosing remote changes';
  EXCEPTION WHEN raise_exception THEN NULL;
  END;
END$$;
SELECT id,note FROM pos3ql_fdw_source WHERE id>=1000 ORDER BY id;
ROLLBACK TO outside_procedure;
SELECT count(*) FROM pos3ql_fdw_source WHERE id>=1000;
COMMIT;
