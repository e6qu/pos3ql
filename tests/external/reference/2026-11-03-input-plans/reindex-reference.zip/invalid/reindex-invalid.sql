CREATE SCHEMA reindex_invalid;
CREATE TABLE reindex_invalid.rows(id integer);
INSERT INTO reindex_invalid.rows VALUES(1),(1);
CREATE UNIQUE INDEX CONCURRENTLY rows_unique ON reindex_invalid.rows(id);
CREATE TABLE reindex_invalid.before AS SELECT oid AS index_oid FROM pg_class WHERE oid='reindex_invalid.rows_unique'::regclass;
SELECT 'failed_build',i.indisunique,i.indisprimary,i.indisvalid,i.indisready,i.indislive
FROM pg_index i WHERE i.indexrelid='reindex_invalid.rows_unique'::regclass;
TRUNCATE reindex_invalid.rows;
REINDEX TABLE CONCURRENTLY reindex_invalid.rows;
SELECT 'table',i.indexrelid=b.index_oid,i.indisunique,i.indisprimary,i.indisvalid,i.indisready,i.indislive
FROM pg_index i,reindex_invalid.before b WHERE i.indexrelid='reindex_invalid.rows_unique'::regclass;
REINDEX INDEX CONCURRENTLY reindex_invalid.rows_unique;
SELECT 'direct',i.indexrelid<>b.index_oid,i.indisunique,i.indisprimary,i.indisvalid,i.indisready,i.indislive
FROM pg_index i,reindex_invalid.before b WHERE i.indexrelid='reindex_invalid.rows_unique'::regclass;
SELECT 'old_removed',count(*) FROM pg_class c,reindex_invalid.before b WHERE c.oid=b.index_oid;
