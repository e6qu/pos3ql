-- session 0: configure-0
SET statement_timeout='3s'; SET lock_timeout='3s';

-- session 1: configure-1
SET statement_timeout='3s'; SET lock_timeout='3s';

-- session 0: dirty_commit-setup
CREATE SCHEMA dirty_commit;

-- session 0: dirty_commit-first-pending
BEGIN; CREATE TABLE dirty_commit.a_b(c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='dirty_commit.a_b'::regclass AND contype='u';

-- session 1: dirty_commit-second-before-release
BEGIN; CREATE TABLE dirty_commit.a(b_c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='dirty_commit.a'::regclass AND contype='u';

-- session 0: dirty_commit-release-first
COMMIT;

-- session 1: dirty_commit-second-after-release
SELECT conname FROM pg_constraint WHERE conrelid='dirty_commit.a'::regclass AND contype='u'; COMMIT;

-- session 0: dirty_commit-persistent
SELECT conname FROM pg_constraint WHERE conrelid='dirty_commit.a'::regclass AND contype='u';

-- session 0: dirty_rollback-setup
CREATE SCHEMA dirty_rollback;

-- session 0: dirty_rollback-first-pending
BEGIN; CREATE TABLE dirty_rollback.a_b(c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='dirty_rollback.a_b'::regclass AND contype='u';

-- session 1: dirty_rollback-second-before-release
BEGIN; CREATE TABLE dirty_rollback.a(b_c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='dirty_rollback.a'::regclass AND contype='u';

-- session 0: dirty_rollback-release-first
ROLLBACK;

-- session 1: dirty_rollback-second-after-release
SELECT conname FROM pg_constraint WHERE conrelid='dirty_rollback.a'::regclass AND contype='u'; COMMIT;

-- session 0: dirty_rollback-persistent
SELECT conname FROM pg_constraint WHERE conrelid='dirty_rollback.a'::regclass AND contype='u';

-- session 0: committed-check-collision
CREATE SCHEMA check_names; CREATE TABLE check_names.holder(value integer CONSTRAINT target_value_key CHECK(value>0)); CREATE TABLE check_names.target(value integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='check_names.target'::regclass AND contype='u';

-- session 0: committed-domain-collision
CREATE DOMAIN check_names.checked AS integer CONSTRAINT other_value_key CHECK(VALUE>0); CREATE TABLE check_names.other(value integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='check_names.other'::regclass AND contype='u';

-- session 0: other-schema-is-independent
CREATE SCHEMA independent_names; CREATE TABLE independent_names.a_b(c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='independent_names.a_b'::regclass AND contype='u';

