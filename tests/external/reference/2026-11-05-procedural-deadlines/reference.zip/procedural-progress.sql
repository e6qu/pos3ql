CREATE FUNCTION progress_timeout_catch() RETURNS text LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    FOR attempt IN 1..2147483647 LOOP NULL; END LOOP;
  EXCEPTION WHEN query_canceled THEN
    PERFORM 1;
    RETURN 'caught';
  END;
  RETURN 'unexpected completion';
END$$;
CREATE FUNCTION progress_timeout_others() RETURNS text LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    FOR attempt IN 1..2147483647 LOOP NULL; END LOOP;
  EXCEPTION WHEN others THEN RETURN 'incorrectly caught';
  END;
  RETURN 'unexpected completion';
END$$;
SET statement_timeout=100;
SELECT progress_timeout_catch();
SELECT progress_timeout_others();
DO $$BEGIN LOOP NULL; END LOOP; END$$;
SET statement_timeout=0;
SELECT 'after';
SELECT current_setting('statement_timeout');
