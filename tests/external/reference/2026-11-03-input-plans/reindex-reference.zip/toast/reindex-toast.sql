CREATE SCHEMA reindex_events;
CREATE TABLE reindex_events.orders(id integer PRIMARY KEY,code text UNIQUE);
INSERT INTO reindex_events.orders VALUES(1,'a'),(2,'b');
CREATE INDEX orders_plain ON reindex_events.orders(code);
CREATE TABLE reindex_events.before AS
 SELECT c.oid AS index_oid,c.relname,k.oid AS constraint_oid
 FROM pg_class c LEFT JOIN pg_constraint k ON k.conindid=c.oid
 WHERE c.relnamespace='reindex_events'::regnamespace AND c.relkind='i';
CREATE TABLE reindex_events.context(stage text);
INSERT INTO reindex_events.context VALUES('setup');
CREATE TABLE reindex_events.events(stage text,kind text,tag text,object_type text,identity text,classid oid,objid oid);
CREATE FUNCTION reindex_events.collect_end() RETURNS event_trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO reindex_events.events
 SELECT x.stage,'end',d.command_tag,d.object_type,d.object_identity,d.classid,d.objid
 FROM reindex_events.context x,pg_event_trigger_ddl_commands() d;
END$$;
CREATE FUNCTION reindex_events.collect_drop() RETURNS event_trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO reindex_events.events
 SELECT x.stage,'drop',TG_TAG,d.object_type,d.object_identity,d.classid,d.objid
 FROM reindex_events.context x,pg_event_trigger_dropped_objects() d;
END$$;
CREATE FUNCTION reindex_events.collect_start() RETURNS event_trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO reindex_events.events
 SELECT x.stage,'start',TG_TAG,NULL,NULL,NULL,NULL FROM reindex_events.context x;
END$$;
CREATE EVENT TRIGGER reindex_end ON ddl_command_end EXECUTE FUNCTION reindex_events.collect_end();
CREATE EVENT TRIGGER reindex_drop ON sql_drop EXECUTE FUNCTION reindex_events.collect_drop();
CREATE EVENT TRIGGER reindex_start ON ddl_command_start EXECUTE FUNCTION reindex_events.collect_start();
DELETE FROM reindex_events.events;
CREATE TABLE reindex_events.toast_before AS
 SELECT t.oid AS toast_oid,i.indexrelid AS index_oid
 FROM pg_class t JOIN pg_index i ON i.indrelid=t.oid
 WHERE t.oid=(SELECT reltoastrelid FROM pg_class WHERE oid='reindex_events.orders'::regclass);
DELETE FROM reindex_events.events;
UPDATE reindex_events.context SET stage='direct_toast';
SELECT format('REINDEX INDEX CONCURRENTLY %s',i.indexrelid::regclass)
FROM pg_index i WHERE i.indrelid=(SELECT reltoastrelid FROM pg_class WHERE oid='reindex_events.orders'::regclass)
\gexec
SELECT 'toast_identity',t.oid=b.toast_oid,i.indexrelid<>b.index_oid
FROM pg_class t JOIN pg_index i ON i.indrelid=t.oid,reindex_events.toast_before b
WHERE t.oid=(SELECT reltoastrelid FROM pg_class WHERE oid='reindex_events.orders'::regclass);
SELECT e.stage,e.kind,e.tag,e.object_type,
 CASE WHEN e.object_type='index' THEN 'toast_index' ELSE e.identity END,
 e.objid=i.indexrelid AS selected_current_index,e.objid=b.index_oid AS selected_old_index
FROM reindex_events.events e
LEFT JOIN pg_index i ON i.indrelid=(SELECT reltoastrelid FROM pg_class WHERE oid='reindex_events.orders'::regclass)
CROSS JOIN reindex_events.toast_before b
ORDER BY e.kind,e.identity;
SELECT 'direct_toast_drop_events',count(*) FROM reindex_events.events WHERE kind='drop';
