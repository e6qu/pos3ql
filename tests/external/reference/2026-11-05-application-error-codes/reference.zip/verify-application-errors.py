"""Verify the retained PostgreSQL reference without running a server."""

import hashlib
import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1]).resolve()
manifest = {}
for line in (root / "SHA256SUMS").read_text().splitlines():
    expected, name = line.split("  ", 1)
    assert Path(name).name == name and name not in manifest
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
    manifest[name] = expected
assert set(manifest) == {path.name for path in root.iterdir() if path.is_file()} - {"SHA256SUMS"}
codes = ["PZ001", "PZ002", "PZ003", "PZ004", "PZ999"]
rows = [f"{code}:{handler}" for code in codes for handler in ["class", "exact", "others"]]
assert (root / "reference.stdout").read_text().splitlines() == rows + ["1", "2"]
errors = re.findall(r"ERROR:\s+([A-Z0-9]{5}):", (root / "reference.stderr").read_text())
assert errors == codes, errors
provenance = json.loads((root / "provenance.json").read_text())
assert provenance["version"] == "postgres (PostgreSQL) 18.6 (Homebrew)"
assert provenance["observed_error_codes"] == codes
commands = json.loads((root / "commands.json").read_text())
server = next(command for command in commands if Path(command[0]).name == "postgres" and "-D" in command)
for setting in ["listen_addresses=", "shared_buffers=16MB", "work_mem=1MB", "max_connections=5"]:
    assert setting in server, setting
print(f"Verified {len(manifest)} reference files, 17 rows and five application errors")
