import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import tempfile
import time

root = Path(__file__).resolve().parent
output = root / 'pending-key-namespace-8800'
output.mkdir(exist_ok=False)
prefix = Path('/opt/homebrew/opt/postgresql@18/bin')
commands = []
steps = []
records = []
sessions = []
environment = {key: value for key, value in os.environ.items() if not key.startswith('PG')}
environment.update({'LC_ALL': 'C', 'LANG': 'C', 'PGAPPNAME': 'pos3ql-key-namespace-reference'})

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def execute(arguments, **options):
    commands.append([str(value) for value in arguments])
    return subprocess.run(arguments, env=environment, check=True, text=True, **options)

def expired(_signum, _frame):
    raise TimeoutError('reference command exceeded its 8-second capture deadline')

signal.signal(signal.SIGALRM, expired)

def command(session, label, sql):
    steps.append(dict(session=session, label=label, sql=sql))
    marker = f'capture_end_{len(records)}'
    process = sessions[session]
    signal.alarm(8)
    try:
        process.stdin.write(f'{sql}\n\\echo {marker}\n')
        process.stdin.flush()
        rows = []
        while True:
            line = process.stdout.readline()
            if not line:
                raise RuntimeError(f'session ended during {label}: {rows}')
            if line.rstrip('\n') == marker:
                break
            rows.append(line.rstrip('\n'))
        record = dict(session=session, label=label, sql=sql, output=rows)
        records.append(record)
        print(json.dumps(record, ensure_ascii=False), flush=True)
        assert not any('ERROR:' in row or 'FATAL:' in row for row in rows), record
    finally:
        signal.alarm(0)

version = execute([prefix / 'postgres', '--version'], capture_output=True).stdout.strip()
assert version == 'postgres (PostgreSQL) 18.6 (Homebrew)', version
(output / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
provenance = dict(
    time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    version=version,
    platform=platform.platform(),
    project_revision='8800db189121059b2d7301a493f37154abd22b92 with uncommitted naming cohort',
    purpose='PostgreSQL pending CHECK namespace visibility; no pos3ql execution or performance qualification',
    guard='/Users/zardoz/.codex/tools/fr-local-guard.py',
    primary_source='https://github.com/postgres/postgres/blob/REL_18_6/src/backend/catalog/pg_constraint.c#L425-L459',
    sources={str(path): digest(path) for path in [Path(__file__), prefix / 'postgres', prefix / 'psql', prefix / 'initdb']},
)
try:
    with tempfile.TemporaryDirectory(prefix='p3-key-namespace-', dir='/private/tmp') as directory:
        temporary = Path(directory)
        data = temporary / 'data'
        sockets = temporary / 'sockets'
        sockets.mkdir(mode=0o700)
        with (output / 'initdb.stdout').open('w') as stdout, (output / 'initdb.stderr').open('w') as stderr:
            execute([prefix / 'initdb', '--pgdata', data, '--username=postgres', '--auth=trust', '--encoding=UTF8', '--locale=C', '--no-sync'], stdout=stdout, stderr=stderr)
        server_arguments = [str(prefix / 'postgres'), '-D', str(data), '-k', str(sockets), '-p', '56383']
        for setting in ['listen_addresses=', 'shared_buffers=16MB', 'wal_buffers=1MB', 'work_mem=1MB', 'maintenance_work_mem=8MB', 'temp_buffers=1MB', 'max_connections=5', 'superuser_reserved_connections=1', 'autovacuum=off', 'max_worker_processes=0', 'max_wal_senders=0', 'wal_level=minimal', 'fsync=off', 'full_page_writes=off', 'synchronous_commit=off', 'max_wal_size=64MB', 'min_wal_size=32MB', 'timezone=UTC']:
            server_arguments.extend(['-c', setting])
        commands.append(server_arguments)
        with (output / 'server.log').open('w') as log:
            server = subprocess.Popen(server_arguments, stdout=log, stderr=subprocess.STDOUT, env=environment)
            try:
                deadline = time.monotonic() + 10
                ready_arguments = [prefix / 'pg_isready', '-h', sockets, '-p', '56383', '-U', 'postgres', '-d', 'postgres']
                provenance['readiness_command'] = [str(value) for value in ready_arguments]
                provenance['readiness_attempts'] = 0
                while True:
                    provenance['readiness_attempts'] += 1
                    ready = subprocess.run(ready_arguments, env=environment, capture_output=True)
                    if ready.returncode == 0:
                        break
                    if server.poll() is not None or time.monotonic() >= deadline:
                        raise RuntimeError('temporary PostgreSQL did not become ready')
                    time.sleep(0.05)
                for session in range(2):
                    arguments = [str(prefix / 'psql'), '-X', '-q', '-A', '-t', '-h', str(sockets), '-p', '56383', '-U', 'postgres', '-d', 'postgres', '--set=ON_ERROR_STOP=1', '--set=VERBOSITY=verbose']
                    commands.append(arguments)
                    sessions.append(subprocess.Popen(arguments, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, env=environment))
                    command(session, f'configure-{session}', "SET statement_timeout='3s'; SET lock_timeout='3s';")
                for kind in ['table', 'domain']:
                    for outcome in ['COMMIT', 'ROLLBACK']:
                        schema = 'pending_' + kind + '_' + outcome.lower()
                        command(0, f'{schema}-setup', f'CREATE SCHEMA {schema};')
                        definition = (f'CREATE TABLE {schema}.holder(value integer CONSTRAINT a_b_c_key CHECK(value>0));' if kind == 'table' else f'CREATE DOMAIN {schema}.holder AS integer CONSTRAINT a_b_c_key CHECK(VALUE>0);')
                        command(0, f'{schema}-first-pending', 'BEGIN; ' + definition)
                        command(1, f'{schema}-second-before-release', f"BEGIN; CREATE TABLE {schema}.a_b(c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='{schema}.a_b'::regclass AND contype='u';")
                        command(0, f'{schema}-release-first', outcome + ';')
                        command(1, f'{schema}-second-after-release', f"SELECT conname FROM pg_constraint WHERE conrelid='{schema}.a_b'::regclass AND contype='u'; COMMIT;")
                        command(0, f'{schema}-persistent', f"SELECT conname FROM pg_constraint WHERE conrelid='{schema}.a_b'::regclass AND contype='u';")
            finally:
                for process in sessions:
                    if process.poll() is None:
                        process.stdin.close()
                        try:
                            process.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
                if server.poll() is None:
                    server.send_signal(signal.SIGINT)
                    try:
                        server.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait()
finally:
    (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    (output / 'steps.json').write_text(json.dumps(steps, indent=2) + '\n')
    (output / 'reference.jsonl').write_text(''.join(json.dumps(record, ensure_ascii=False) + '\n' for record in records))
    (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    files = sorted(path for path in output.iterdir() if path.is_file() and path.name != 'SHA256SUMS')
    (output / 'SHA256SUMS').write_text(''.join(f'{digest(path)}  {path.name}\n' for path in files))
