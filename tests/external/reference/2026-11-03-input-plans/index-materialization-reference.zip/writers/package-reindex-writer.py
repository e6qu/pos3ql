import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'reindex-writer-reference'
verifier=r'''import hashlib,json,struct,sys
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1)
 assert Path(name).name==name and name not in checks
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
entries=json.loads((root/'transcript.json').read_text());assert len(entries)==35
assert not any(kind=='K' for entry in entries for kind,payload in entry['messages'])
by_label={e['label']:e for e in entries}
for label in by_label:
 matches=[e for e in entries if e['label']==label]
 if len(matches)>1:
  assert label in ('registered-ordinary','registered-deferred')
  assert all(not any(k=='D' for k,p in e['messages']) for e in matches[:-1])
def row(label):
 payload=next(bytes.fromhex(p) for k,p in by_label[label]['messages'] if k=='D')
 assert struct.unpack('!h',payload[:2])[0]==1
 n=struct.unpack('!i',payload[2:6])[0];assert len(payload)==n+6
 return payload[6:].decode()
for suffix,immediate in [('ordinary','true'),('deferred','false')]:
 assert row('registered-'+suffix)=='false:false:true:'+immediate
 original=row('original-'+suffix);assert original.isdigit()
 assert row('constraint-before-cancel-'+suffix)==original
 assert row('cancel-'+suffix)=='t'
 assert any(k=='E' and b'C57014\0' in bytes.fromhex(p) for k,p in by_label['cancel-result-'+suffix]['messages'])
 assert by_label['cancel-result-'+suffix]['messages'][-1]==['Z','49']
 assert row('constraint-after-cancel-'+suffix)==original
 assert row('replacement-after-cancel-'+suffix)=='1'
 assert row('replaced-'+suffix)=='t'
 request=bytes.fromhex(by_label['begin-reindex-'+suffix]['request_hex'])
 assert request[:1]==b'Q' and request[5:]==('REINDEX INDEX CONCURRENTLY writer_reindex_'+suffix+'_pkey\0').encode()
provenance=json.loads((root/'provenance.json').read_text());assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
commands=json.loads((root/'commands.json').read_text());server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
print(json.dumps({'verified_files':len(checks),'protocol_exchanges':len(entries),'qualification':'PostgreSQL reference semantics only'}))
'''
(source/'verify-reindex-writer.py').write_text(verifier)
(source/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
files=sorted(p for p in source.iterdir() if p.is_file() and p.name!='SHA256SUMS')
(source/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files))
destination=root/'reindex-writer-reference.zip'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
 for p in sorted(source.iterdir()):
  if p.is_file():archive.write(p,p.name)
print(json.dumps({'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'bytes':destination.stat().st_size}))
