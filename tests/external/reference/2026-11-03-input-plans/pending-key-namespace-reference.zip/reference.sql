-- session 0: configure-0
SET statement_timeout='3s'; SET lock_timeout='3s';

-- session 1: configure-1
SET statement_timeout='3s'; SET lock_timeout='3s';

-- session 0: pending_table_commit-setup
CREATE SCHEMA pending_table_commit;

-- session 0: pending_table_commit-first-pending
BEGIN; CREATE TABLE pending_table_commit.holder(value integer CONSTRAINT a_b_c_key CHECK(value>0));

-- session 1: pending_table_commit-second-before-release
BEGIN; CREATE TABLE pending_table_commit.a_b(c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='pending_table_commit.a_b'::regclass AND contype='u';

-- session 0: pending_table_commit-release-first
COMMIT;

-- session 1: pending_table_commit-second-after-release
SELECT conname FROM pg_constraint WHERE conrelid='pending_table_commit.a_b'::regclass AND contype='u'; COMMIT;

-- session 0: pending_table_commit-persistent
SELECT conname FROM pg_constraint WHERE conrelid='pending_table_commit.a_b'::regclass AND contype='u';

-- session 0: pending_table_rollback-setup
CREATE SCHEMA pending_table_rollback;

-- session 0: pending_table_rollback-first-pending
BEGIN; CREATE TABLE pending_table_rollback.holder(value integer CONSTRAINT a_b_c_key CHECK(value>0));

-- session 1: pending_table_rollback-second-before-release
BEGIN; CREATE TABLE pending_table_rollback.a_b(c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='pending_table_rollback.a_b'::regclass AND contype='u';

-- session 0: pending_table_rollback-release-first
ROLLBACK;

-- session 1: pending_table_rollback-second-after-release
SELECT conname FROM pg_constraint WHERE conrelid='pending_table_rollback.a_b'::regclass AND contype='u'; COMMIT;

-- session 0: pending_table_rollback-persistent
SELECT conname FROM pg_constraint WHERE conrelid='pending_table_rollback.a_b'::regclass AND contype='u';

-- session 0: pending_domain_commit-setup
CREATE SCHEMA pending_domain_commit;

-- session 0: pending_domain_commit-first-pending
BEGIN; CREATE DOMAIN pending_domain_commit.holder AS integer CONSTRAINT a_b_c_key CHECK(VALUE>0);

-- session 1: pending_domain_commit-second-before-release
BEGIN; CREATE TABLE pending_domain_commit.a_b(c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='pending_domain_commit.a_b'::regclass AND contype='u';

-- session 0: pending_domain_commit-release-first
COMMIT;

-- session 1: pending_domain_commit-second-after-release
SELECT conname FROM pg_constraint WHERE conrelid='pending_domain_commit.a_b'::regclass AND contype='u'; COMMIT;

-- session 0: pending_domain_commit-persistent
SELECT conname FROM pg_constraint WHERE conrelid='pending_domain_commit.a_b'::regclass AND contype='u';

-- session 0: pending_domain_rollback-setup
CREATE SCHEMA pending_domain_rollback;

-- session 0: pending_domain_rollback-first-pending
BEGIN; CREATE DOMAIN pending_domain_rollback.holder AS integer CONSTRAINT a_b_c_key CHECK(VALUE>0);

-- session 1: pending_domain_rollback-second-before-release
BEGIN; CREATE TABLE pending_domain_rollback.a_b(c integer UNIQUE); SELECT conname FROM pg_constraint WHERE conrelid='pending_domain_rollback.a_b'::regclass AND contype='u';

-- session 0: pending_domain_rollback-release-first
ROLLBACK;

-- session 1: pending_domain_rollback-second-after-release
SELECT conname FROM pg_constraint WHERE conrelid='pending_domain_rollback.a_b'::regclass AND contype='u'; COMMIT;

-- session 0: pending_domain_rollback-persistent
SELECT conname FROM pg_constraint WHERE conrelid='pending_domain_rollback.a_b'::regclass AND contype='u';

