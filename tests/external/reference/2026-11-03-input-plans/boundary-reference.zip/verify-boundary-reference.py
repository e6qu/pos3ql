import hashlib
import json
from pathlib import Path
import re
import sys

directory = Path(sys.argv[1])
files = {}
for line in (directory / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert '/' not in name and name not in files
    assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == digest, name
    files[name] = digest
assert set(files) == {path.name for path in directory.iterdir() if path.is_file()} - {'SHA256SUMS'}
provenance = json.loads((directory / 'provenance.json').read_text())
assert provenance['version'] == 'postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes'] == ['42883', '42601', '42601', '42601', '42P01']
for name, expected in provenance['sources'].items():
    if Path(name).name in ['boundary-reference.sql', 'run-boundary-reference.py']:
        assert files[Path(name).name] == expected
assert re.findall(r'ERROR:\s+([A-Z0-9]{5}):', (directory / 'reference.stderr').read_text()) == provenance['observed_error_codes']
labels = ['error_order', 'zero_column_relation', 'cursor_timing', 'checked_defaults_and_prepare', 'owner_events', 'initialized_attributes']
blocks = {label: [] for label in labels}
label = None
for line in (directory / 'reference.stdout').read_text().splitlines():
    if line in blocks:
        label = line
    elif line:
        assert label is not None
        blocks[label].append(line)
assert blocks['error_order'] == []
assert blocks['zero_column_relation'] == ['1']
assert blocks['cursor_timing'] == ['f', 'f', '1', '1|t', 't', '7']
assert blocks['checked_defaults_and_prepare'] == ['t', '1', '2', '2', '3', '3', '4', '{1}', '4']
assert blocks['owner_events'] == [
    'ALTER SERVER|server|boundary_server',
    'ALTER SERVER|server|boundary_server',
    'ALTER SERVER|server|boundary_server',
    'ALTER FOREIGN DATA WRAPPER|foreign-data wrapper|boundary_wrapper',
    'COMMENT|foreign-data wrapper|boundary_wrapper',
    'COMMENT|server|boundary_server',
    'foreign-data wrapper|boundary_wrapper',
    'server|boundary_server',
    't', 't',
]
assert blocks['initialized_attributes'][:3] == ['6183|ts_debug|100', '6184|ts_debug|100', 't']
assert blocks['initialized_attributes'][3].startswith('PostgreSQL 18.6 (Homebrew)')
assert blocks['initialized_attributes'][3].endswith('|UTF8|C')
print(json.dumps({'verified_files': len(files), 'observations': blocks}, indent=2))
