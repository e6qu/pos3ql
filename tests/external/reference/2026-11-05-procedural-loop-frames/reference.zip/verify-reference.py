"""Verify retained PostgreSQL inputs, results, configuration and hashes."""

import hashlib
import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1]).resolve()
for directory in [root, root / "input-validation", root / "numeric-loops"]:
    manifest = {}
    for line in (directory / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        assert not Path(name).is_absolute() and ".." not in Path(name).parts
        assert name not in manifest
        assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == expected, name
        manifest[name] = expected
    actual = {str(path.relative_to(directory)) for path in directory.rglob("*") if path.is_file()}
    assert set(manifest) == actual - {"SHA256SUMS"}

for name, rows, errors in [
    ("input-validation", ["t", "f", "f", "23514", "22P02"],
     ["22012", "22012"] + [code for code in ["PZ001", "PZ002", "PZ003", "PZ004", "PZ999", "22012", "23514", "57014"] for _ in range(6)]),
    ("numeric-loops", ["32767|outside|1|t", "outside|5", "returned:1:1"], []),
]:
    directory = root / name
    assert (directory / "reference.stdout").read_text().splitlines() == rows
    observed = re.findall(r"ERROR:\s+([A-Z0-9]{5}):", (directory / "reference.stderr").read_text())
    assert observed == errors, (name, observed)
    provenance = json.loads((directory / "provenance.json").read_text())
    assert provenance["version"] == "postgres (PostgreSQL) 18.6 (Homebrew)"
    assert provenance["observed_error_codes"] == errors
    commands = json.loads((directory / "commands.json").read_text())
    server = next(command for command in commands if Path(command[0]).name == "postgres" and "-D" in command)
    for setting in ["listen_addresses=", "shared_buffers=16MB", "work_mem=1MB", "max_connections=5"]:
        assert setting in server
print("Verified input validation: five rows and 50 intentional errors; numeric loops: three rows, no errors")
