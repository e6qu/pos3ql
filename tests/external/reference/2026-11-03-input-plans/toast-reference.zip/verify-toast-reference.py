SQL_HASH='908e33b3939a404b5558b006a8a00b0e1221a6a937076260bfadddfe83dfc94a'
EXPECTED=['before|t|t|t|t|t|t|1 2|2|2|0 0|oid_ops,int4_ops','attributes|1|chunk_id|26|f','attributes|2|chunk_seq|23|f','before-dependencies|pg_class|index|0|pg_class|toast|1|a','before-dependencies|pg_class|index|0|pg_class|toast|2|a','before-dependencies|pg_class|toast|0|pg_class|owner|0|i','after|t|t|t|t|t|t|1 2|2|2|0 0|oid_ops,int4_ops|t|t','after-dependencies|pg_class|index|0|pg_class|toast|1|a','after-dependencies|pg_class|index|0|pg_class|toast|2|a','after-dependencies|pg_class|toast|0|pg_class|owner|0|i','t']
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert name not in checks and Path(name).name==name
    assert re.fullmatch('[0-9a-f]{64}',digest)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
assert checks['222_toast_index_identities.sql']==SQL_HASH
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert not (root/'reference.stderr').read_text()
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes']==[]
assert provenance['project_revision']=='5119b065b18405deff619a60a45151fcbdb4fe34 with uncommitted fixture222; exact source hash recorded'
assert SQL_HASH in provenance['sources'].values()
for name,digest in provenance['sources'].items():
    assert re.fullmatch('[0-9a-f]{64}',digest)
    copied=root/Path(name).name
    if copied.exists(): assert hashlib.sha256(copied.read_bytes()).hexdigest()==digest
commands=json.loads((root/'commands.json').read_text())
server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
assert any(Path(c[0]).name=='psql' and '--set=VERBOSITY=verbose' in c for c in commands)
print(json.dumps({'verified_files':len(checks),'sql_sha256':SQL_HASH,'output_rows':len(EXPECTED),'qualification':'PostgreSQL reference semantics only; final pos3ql CI required'}))
