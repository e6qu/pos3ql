import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import socket
import struct
import subprocess
import tempfile
import time

root = Path(__file__).resolve().parent
output = root / "protocol-reference-1edfb4bf-v4"
output.mkdir(exist_ok=False)
prefix = Path("/opt/homebrew/opt/postgresql@18/bin")
environment = {key: value for key, value in os.environ.items() if not key.startswith("PG")}
environment.update({"LC_ALL": "C", "LANG": "C"})
commands = []
transcript = []


def run(arguments, **options):
    commands.append([str(value) for value in arguments])
    return subprocess.run(arguments, env=environment, check=True, text=True, **options)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frontend(kind, payload=b""):
    return kind + struct.pack("!I", len(payload) + 4) + payload


def exact(connection, size):
    result = b""
    while len(result) < size:
        part = connection.recv(size - len(result))
        if not part:
            raise EOFError("reference connection closed")
        result += part
    return result


def exchange(connection, label, message, terminal):
    if message[:1] in {b"P", b"B", b"E", b"C"}:
        message += frontend(b"H")
    connection.sendall(message)
    responses = []
    while True:
        kind = exact(connection, 1)
        size = struct.unpack("!I", exact(connection, 4))[0]
        payload = exact(connection, size - 4)
        responses.append((kind, payload))
        if kind in terminal:
            break
    transcript.append({"label": label, "messages": [(kind.decode(), payload.hex()) for kind, payload in responses if kind != b"K"]})
    return responses


def query(connection, label, sql):
    return exchange(connection, label, frontend(b"Q", sql.encode() + b"\0"), {b"Z"})


def parse(connection, label, sql, name=""):
    return exchange(connection, label, frontend(b"P", name.encode() + b"\0" + sql.encode() + b"\0\0\0"), {b"1", b"E"})


def bind(connection, label, name="", portal="", parameter=None):
    payload = portal.encode() + b"\0" + name.encode() + b"\0\0\0"
    if parameter is None:
        payload += b"\0\0"
    else:
        value = parameter.encode()
        payload += struct.pack("!hI", 1, len(value)) + value
    return exchange(connection, label, frontend(b"B", payload + b"\0\0"), {b"2", b"E"})


def execute(connection, label, portal=""):
    return exchange(connection, label, frontend(b"E", portal.encode() + b"\0" + bytes(4)), {b"C", b"E"})


def sync(connection, label):
    return exchange(connection, label, frontend(b"S"), {b"Z"})


def first_row(messages):
    payload = next(payload for kind, payload in messages if kind == b"D")
    size = struct.unpack("!i", payload[2:6])[0]
    return payload[6:6 + size].decode()


version = run([prefix / "postgres", "--version"], capture_output=True).stdout.strip()
assert version == "postgres (PostgreSQL) 18.6 (Homebrew)", version
provenance = {"time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "version": version, "platform": platform.platform(),
              "project_revision": "1edfb4bf", "guard": "/Users/zardoz/.codex/tools/fr-local-guard.py",
              "purpose": "PostgreSQL protocol and planning reference, no pos3ql execution",
              "omitted_fields": ["startup BackendKeyData cancel identifiers"],
              "sources": {str(path): digest(path) for path in [Path(__file__), prefix / "postgres", prefix / "initdb"]}}
try:
    with tempfile.TemporaryDirectory(prefix="p3-protocol-", dir="/private/tmp") as directory:
        temporary = Path(directory)
        data = temporary / "data"
        sockets = temporary / "sockets"
        sockets.mkdir(mode=0o700)
        with (output / "initdb.stdout").open("w") as stdout, (output / "initdb.stderr").open("w") as stderr:
            run([prefix / "initdb", "--pgdata", data, "--username=postgres", "--auth=trust", "--encoding=UTF8", "--locale=C", "--no-sync"], stdout=stdout, stderr=stderr)
        arguments = [str(prefix / "postgres"), "-D", str(data), "-k", str(sockets), "-p", "56379"]
        for setting in ["listen_addresses=", "shared_buffers=16MB", "wal_buffers=1MB", "work_mem=1MB", "maintenance_work_mem=8MB", "temp_buffers=1MB", "max_connections=5", "superuser_reserved_connections=1", "autovacuum=off", "max_worker_processes=0", "max_wal_senders=0", "wal_level=minimal", "fsync=off", "full_page_writes=off", "synchronous_commit=off", "max_wal_size=64MB", "min_wal_size=32MB", "timezone=UTC"]:
            arguments.extend(["-c", setting])
        commands.append(arguments)
        with (output / "server.log").open("w") as log:
            server = subprocess.Popen(arguments, env=environment, stdout=log, stderr=subprocess.STDOUT)
            connections = []
            try:
                deadline = time.monotonic() + 20
                while not (sockets / ".s.PGSQL.56379").exists():
                    if server.poll() is not None or time.monotonic() >= deadline:
                        raise RuntimeError("PostgreSQL reference did not become ready")
                    time.sleep(0.05)
                for index in range(2):
                    connection = socket.socket(socket.AF_UNIX)
                    connection.settimeout(10)
                    connection.connect(str(sockets / ".s.PGSQL.56379"))
                    connections.append(connection)
                    startup = struct.pack("!I", 196608) + b"user\0postgres\0database\0postgres\0\0"
                    exchange(connection, f"startup-{index}", struct.pack("!I", len(startup) + 4) + startup, {b"Z"})
                connection, observer = connections
                query(connection, "portal-begin", "BEGIN")
                parse(connection, "portal-parse", "SELECT 7", "duplicate_portal_statement")
                bind(connection, "portal-first-bind", "duplicate_portal_statement", "duplicate_portal")
                duplicate = bind(connection, "portal-duplicate-bind", "duplicate_portal_statement", "duplicate_portal")
                assert any(b"C42P03\0" in payload for kind, payload in duplicate if kind == b"E")
                assert sync(connection, "portal-error-sync")[-1] == (b"Z", b"E")
                failed = execute(connection, "portal-execute-failed-block", "duplicate_portal")
                assert any(b"C25P02\0" in payload for kind, payload in failed if kind == b"E")
                sync(connection, "portal-failed-execute-sync")
                query(connection, "portal-rollback", "ROLLBACK")
                query(connection, "utility-table", "CREATE TABLE utility_rows(id integer); INSERT INTO utility_rows VALUES(1)")
                for sql, tag, observation, expected in [
                    ("CREATE INDEX CONCURRENTLY utility_index ON utility_rows(id)", "CREATE INDEX", "SELECT count(*) FROM pg_class WHERE relname='utility_index'", "1"),
                    ("REINDEX INDEX CONCURRENTLY utility_index", "REINDEX", "SELECT count(*) FROM pg_class WHERE relname='utility_index'", "1"),
                    ("DROP INDEX CONCURRENTLY utility_index", "DROP INDEX", "SELECT count(*) FROM pg_class WHERE relname='utility_index'", "0"),
                    ("CREATE DATABASE utility_database", "CREATE DATABASE", "SELECT count(*) FROM pg_database WHERE datname='utility_database'", "1"),
                    ("DROP DATABASE utility_database", "DROP DATABASE", "SELECT count(*) FROM pg_database WHERE datname='utility_database'", "0"),
                ]:
                    parse(connection, "utility-parse:" + sql, sql)
                    bind(connection, "utility-bind:" + sql)
                    completion = execute(connection, "utility-execute:" + sql)
                    assert completion[-1] == (b"C", tag.encode() + b"\0"), completion
                    first_row(query(observer, "utility-visible-before-sync:" + sql, observation))
                    query(observer, "utility-index-before-sync:" + sql, "SELECT indisvalid::text||':'||indisready::text FROM pg_index JOIN pg_class ON indexrelid=pg_class.oid WHERE relname='utility_index'")
                    assert sync(connection, "utility-sync:" + sql)[-1] == (b"Z", b"I")
                    assert first_row(query(observer, "utility-visible-after-sync:" + sql, observation)) == expected
                query(connection, "pruning-setup", "CREATE SEQUENCE bind_branch_checks; CREATE TYPE bind_branch_choice AS ENUM('a'); CREATE DOMAIN bind_branch_checked AS bind_branch_choice CHECK(nextval('bind_branch_checks')>0); CREATE FUNCTION bind_branch() RETURNS integer LANGUAGE sql AS $$SELECT cardinality('{a}'::bind_branch_checked[])$$; ALTER SEQUENCE bind_branch_checks RESTART WITH 1")
                for sql, unused, used in [("SELECT CASE WHEN $1=0 THEN bind_branch() ELSE 17 END", "1", "0"), ("SELECT CASE WHEN $1='go' THEN bind_branch() ELSE 17 END", "stop", "go")]:
                    parse(connection, "pruning-parse:" + sql, sql, "branch")
                    for parameter in [unused, used]:
                        bind(connection, "pruning-bind:" + parameter, "branch", "", parameter)
                        first_row(query(observer, "pruning-checks-after-bind:" + parameter, "SELECT last_value::text||':'||is_called::text FROM bind_branch_checks"))
                        execute(connection, "pruning-execute:" + parameter)
                        sync(connection, "pruning-sync:" + parameter)
                    exchange(connection, "pruning-close", frontend(b"C", b"Sbranch\0"), {b"3", b"E"})
                    query(connection, "pruning-reset", "ALTER SEQUENCE bind_branch_checks RESTART WITH 1")
            finally:
                for connection in connections:
                    connection.close()
                if server.poll() is None:
                    server.send_signal(signal.SIGINT)
                    try:
                        server.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait()
    print(json.dumps({"version": version, "transcript_entries": len(transcript)}, indent=2))
finally:
    (output / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    (output / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
    (output / "transcript.json").write_text(json.dumps(transcript, indent=2) + "\n")
    (output / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    (output / "SHA256SUMS").write_text("".join(f"{digest(path)}  {path.name}\n" for path in sorted(output.iterdir()) if path.is_file() and path.name != "SHA256SUMS"))
