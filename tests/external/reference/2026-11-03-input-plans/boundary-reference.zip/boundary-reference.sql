\echo error_order
SELECT true+1,*;
SELECT *,true+1;
SELECT * LIMIT 0;
SELECT *,1/0 LIMIT 0;
SELECT missing.* LIMIT 0;
\echo zero_column_relation
CREATE TABLE boundary_zero();
INSERT INTO boundary_zero DEFAULT VALUES;
SELECT count(*) FROM boundary_zero;
\echo cursor_timing
CREATE SEQUENCE boundary_numbers;
BEGIN;
DECLARE boundary_cursor CURSOR FOR SELECT nextval('boundary_numbers');
SELECT is_scrollable FROM pg_cursors WHERE name='boundary_cursor';
FETCH 0 FROM boundary_cursor;
SELECT is_called FROM boundary_numbers;
FETCH 1 FROM boundary_cursor;
FETCH 1 FROM boundary_cursor;
SELECT last_value,is_called FROM boundary_numbers;
CLOSE boundary_cursor;
DECLARE boundary_cursor SCROLL CURSOR FOR SELECT 7;
SELECT is_scrollable FROM pg_cursors WHERE name='boundary_cursor';
FETCH 1 FROM boundary_cursor;
CLOSE boundary_cursor;
DECLARE boundary_cursor NO SCROLL CURSOR FOR SELECT * FROM boundary_zero;
FETCH 1 FROM boundary_cursor;
CLOSE boundary_cursor;
COMMIT;
\echo checked_defaults_and_prepare
CREATE SEQUENCE boundary_checks;
CREATE DOMAIN boundary_checked AS integer CHECK(nextval('boundary_checks')>0);
SELECT NULL::boundary_checked IS NULL;
SELECT last_value FROM boundary_checks;
CREATE DOMAIN boundary_array AS boundary_checked[] DEFAULT '{1}';
SELECT last_value FROM boundary_checks;
CREATE TABLE boundary_defaults(value boundary_array);
INSERT INTO boundary_defaults DEFAULT VALUES;
INSERT INTO boundary_defaults DEFAULT VALUES;
SELECT last_value FROM boundary_checks;
CREATE TABLE boundary_values(value boundary_checked[]);
CREATE VIEW boundary_view AS SELECT value FROM boundary_values;
ALTER VIEW boundary_view ALTER COLUMN value SET DEFAULT '{1}';
SELECT last_value FROM boundary_checks;
INSERT INTO boundary_view DEFAULT VALUES;
SELECT last_value FROM boundary_checks;
PREPARE boundary_plan AS SELECT '{1}'::boundary_checked[];
SELECT last_value FROM boundary_checks;
EXECUTE boundary_plan;
SELECT last_value FROM boundary_checks;
DEALLOCATE boundary_plan;
\echo owner_events
CREATE ROLE boundary_owner;
CREATE FOREIGN DATA WRAPPER boundary_wrapper;
CREATE SERVER boundary_server FOREIGN DATA WRAPPER boundary_wrapper;
CREATE TABLE boundary_events(tag text,kind text,identity text);
CREATE FUNCTION boundary_capture() RETURNS event_trigger LANGUAGE plpgsql AS
$$BEGIN INSERT INTO boundary_events SELECT command_tag,object_type,object_identity
FROM pg_event_trigger_ddl_commands(); RETURN; END$$;
CREATE EVENT TRIGGER boundary_event ON ddl_command_end WHEN TAG IN ('ALTER SERVER','ALTER FOREIGN DATA WRAPPER')
EXECUTE FUNCTION boundary_capture();
ALTER SERVER boundary_server OWNER TO postgres;
ALTER SERVER boundary_server OWNER TO boundary_owner;
ALTER SERVER boundary_server OWNER TO boundary_owner;
SELECT tag,kind,identity FROM boundary_events;
ALTER FOREIGN DATA WRAPPER boundary_wrapper OWNER TO postgres;
SELECT tag,kind,identity FROM boundary_events WHERE tag='ALTER FOREIGN DATA WRAPPER';
DROP EVENT TRIGGER boundary_event;
CREATE EVENT TRIGGER boundary_event ON ddl_command_end WHEN TAG IN ('COMMENT')
EXECUTE FUNCTION boundary_capture();
COMMENT ON FOREIGN DATA WRAPPER boundary_wrapper IS 'reference';
COMMENT ON SERVER boundary_server IS 'reference';
SELECT tag,kind,identity FROM boundary_events WHERE tag='COMMENT' ORDER BY kind;
SELECT type,identity FROM pg_identify_object('pg_foreign_data_wrapper'::regclass,(SELECT oid FROM pg_foreign_data_wrapper WHERE fdwname='boundary_wrapper'),0);
SELECT type,identity FROM pg_identify_object('pg_foreign_server'::regclass,(SELECT oid FROM pg_foreign_server WHERE srvname='boundary_server'),0);
SELECT classid='pg_foreign_data_wrapper'::regclass AND objid=(SELECT oid FROM pg_foreign_data_wrapper WHERE fdwname='boundary_wrapper') FROM pg_get_object_address('foreign-data wrapper',ARRAY['boundary_wrapper'],ARRAY[]::text[]);
SELECT classid='pg_foreign_server'::regclass AND objid=(SELECT oid FROM pg_foreign_server WHERE srvname='boundary_server') FROM pg_get_object_address('server',ARRAY['boundary_server'],ARRAY[]::text[]);
DROP EVENT TRIGGER boundary_event;
\echo initialized_attributes
SELECT oid,proname,procost FROM pg_proc WHERE oid IN (6183,6184) ORDER BY oid;
SELECT proretset FROM pg_proc WHERE oid='information_schema._pg_expandarray(anyarray)'::regprocedure;
SELECT version(),current_setting('server_encoding'),datcollate FROM pg_database WHERE datname=current_database();
