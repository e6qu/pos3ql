CREATE SCHEMA reindex_dependencies;
CREATE TABLE reindex_dependencies.rows(id integer PRIMARY KEY,body text);
INSERT INTO reindex_dependencies.rows VALUES(1,'a');
WITH selected AS (
 SELECT c.oid AS owner_oid,c.reltoastrelid AS toast_oid,i.indexrelid AS index_oid
 FROM pg_class c JOIN pg_index i ON i.indrelid=c.reltoastrelid
 WHERE c.oid='reindex_dependencies.rows'::regclass
)
SELECT 'before',d.classid::regclass::text,
 CASE d.objid WHEN s.owner_oid THEN 'owner' WHEN s.toast_oid THEN 'toast' WHEN s.index_oid THEN 'index' ELSE pg_describe_object(d.classid,d.objid,d.objsubid) END,
 d.objsubid,d.refclassid::regclass::text,
 CASE d.refobjid WHEN s.owner_oid THEN 'owner' WHEN s.toast_oid THEN 'toast' WHEN s.index_oid THEN 'index' ELSE pg_describe_object(d.refclassid,d.refobjid,d.refobjsubid) END,
 d.refobjsubid,d.deptype
FROM pg_depend d,selected s
WHERE d.classid='pg_class'::regclass AND d.objid IN(s.toast_oid,s.index_oid)
ORDER BY 3,d.objsubid,5,6,d.refobjsubid,d.deptype;
REINDEX TABLE CONCURRENTLY reindex_dependencies.rows;
WITH selected AS (
 SELECT c.oid AS owner_oid,c.reltoastrelid AS toast_oid,i.indexrelid AS index_oid
 FROM pg_class c JOIN pg_index i ON i.indrelid=c.reltoastrelid
 WHERE c.oid='reindex_dependencies.rows'::regclass
)
SELECT 'after',d.classid::regclass::text,
 CASE d.objid WHEN s.owner_oid THEN 'owner' WHEN s.toast_oid THEN 'toast' WHEN s.index_oid THEN 'index' ELSE pg_describe_object(d.classid,d.objid,d.objsubid) END,
 d.objsubid,d.refclassid::regclass::text,
 CASE d.refobjid WHEN s.owner_oid THEN 'owner' WHEN s.toast_oid THEN 'toast' WHEN s.index_oid THEN 'index' ELSE pg_describe_object(d.refclassid,d.refobjid,d.refobjsubid) END,
 d.refobjsubid,d.deptype
FROM pg_depend d,selected s
WHERE d.classid='pg_class'::regclass AND d.objid IN(s.toast_oid,s.index_oid)
ORDER BY 3,d.objsubid,5,6,d.refobjsubid,d.deptype;
