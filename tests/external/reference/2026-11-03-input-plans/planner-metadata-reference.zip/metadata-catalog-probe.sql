SELECT oid,opcmethod,opcname,opcfamily,opcintype,opcdefault,opckeytype FROM pg_opclass WHERE opcmethod IN (403,405) ORDER BY oid;
SELECT oid,opfmethod,opfname FROM pg_opfamily WHERE opfmethod IN (403,405) ORDER BY oid;
SELECT length(DISTINCT 'x');
CREATE SCHEMA reference_scope;
CREATE TABLE reference_scope.source(value integer);
SELECT reference_scope.source.value FROM reference_scope.source AS selected;
SELECT (SELECT reference_scope.source.value) FROM reference_scope.source AS selected;
