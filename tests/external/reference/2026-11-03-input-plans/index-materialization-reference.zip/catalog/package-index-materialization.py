import hashlib,json,re,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'index-materialization-reference'
expected=['created|2|2|1|2','materialized|2|2|1|2','inline_key_materialization_pkey|t|t|t','inline_key_materialization_value_key|f|t|t','2|2','replaced|2|2|1|2','inline_key_materialization_pkey|t|t|t','inline_key_materialization_value_key|f|t|t','0','1|10|one','2|20|two']
assert (source/'reference.stdout').read_text().splitlines()==expected
assert re.findall(r'ERROR:\s+([A-Z0-9]{5}):',(source/'reference.stderr').read_text())==[]
verifier=r'''import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert Path(name).name==name and name not in checks
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
assert (root/'planner-drop.sql').read_bytes()==(root/'233_inline_index_materialization.sql').read_bytes()
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert not re.findall(r'ERROR:\s+([A-Z0-9]{5}):',(root/'reference.stderr').read_text())
provenance=json.loads((root/'provenance.json').read_text());assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert checks['233_inline_index_materialization.sql'] in provenance['sources'].values()
commands=json.loads((root/'commands.json').read_text());server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
print(json.dumps({'verified_files':len(checks),'catalog_rows':len(EXPECTED),'qualification':'PostgreSQL reference semantics only'}))
'''
(source/'verify-catalog.py').write_text('EXPECTED='+repr(expected)+'\n'+verifier)
(source/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
files=sorted(p for p in source.iterdir() if p.is_file() and p.name!='SHA256SUMS')
(source/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files))
wrapper='''import hashlib,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert not Path(name).is_absolute() and '..' not in Path(name).parts and name not in checks
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert set(checks)=={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}-{'SHA256SUMS'}
subprocess.run([sys.executable,str(root/'catalog/verify-catalog.py'),str(root/'catalog')],check=True)
subprocess.run([sys.executable,str(root/'writers/verify-reindex-writer.py'),str(root/'writers')],check=True)
print('index-materialization reference: verified',len(checks),'file hashes')
'''
contents={'verify-index-materialization.py':wrapper.encode(),'README.txt':b'PostgreSQL 18.6 reference semantics only, not pos3ql runtime or performance evidence. Catalog: fixture233 inline indexes remain one relation after tablespace materialization and replacement. Writers: ordinary/deferred primary-key replacement publishes before waiting, and cancellation preserves committed index registration. Raw commands, SQL/protocol, binary/source hashes and scripts are retained in each directory. Run python3 verify-index-materialization.py EXTRACTED_DIRECTORY.\n'}
for directory,prefix in [(source,'catalog'),(root/'reindex-writer-reference','writers')]:
 for p in sorted(directory.iterdir()):
  if p.is_file():contents[prefix+'/'+p.name]=p.read_bytes()
contents['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(contents.items())).encode()
destination=root.parent/'share-statistics-capacity/tests/external/reference/2026-11-03-input-plans/index-materialization-reference.zip'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,data in sorted(contents.items()):archive.writestr(name,data)
print(json.dumps({'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'bytes':destination.stat().st_size}))
