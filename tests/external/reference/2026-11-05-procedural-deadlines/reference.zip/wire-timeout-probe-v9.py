import json
from pathlib import Path
import socket
import struct
import sys
import time

host,port,destination=sys.argv[1:]
port=int(port)
def frame(kind,payload=b''):
 return kind+struct.pack('!I',len(payload)+4)+payload
def exact(connection,count):
 value=b''
 while len(value)<count:
  chunk=connection.recv(count-len(value))
  if not chunk:raise RuntimeError('connection closed')
  value+=chunk
 return value
def receive(connection):
 kind=exact(connection,1);size=struct.unpack('!I',exact(connection,4))[0]
 assert 4<=size<1024*1024
 return kind,exact(connection,size-4)
def until(connection,last):
 output=[]
 while True:
  value=receive(connection);output.append(value)
  if value[0]==last:return output
def query(connection,sql):
 connection.sendall(frame(b'Q',sql.encode()+b'\0'))
 return until(connection,b'Z')
def connect():
 connection=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);connection.settimeout(1)
 connection.connect(f'{host}/.s.PGSQL.{port}')
 payload=struct.pack('!I',196608)+b'user\0postgres\0database\0postgres\0client_encoding\0UTF8\0\0'
 connection.sendall(struct.pack('!I',len(payload)+4)+payload);until(connection,b'Z')
 query(connection,'SET statement_timeout=100')
 return connection
def error_state(payload):
 for field in payload.split(b'\0'):
  if field[:1]==b'C':return field[1:].decode()
 return None
def expire(connection):
 connection.settimeout(.4)
 try:
  while True:
   kind,payload=receive(connection)
   if kind==b'E':return error_state(payload)
 except TimeoutError:return None
 finally:connection.settimeout(1)

def parse(connection):
 connection.sendall(frame(b'P',b's\0SELECT pg_sleep(0.02),7\0'+struct.pack('!H',0))+frame(b'H'))
 until(connection,b'1')
results={}
for mode in ['parse','bind','describe']:
 with connect() as connection:
  parse(connection)
  if mode!='parse':
   connection.sendall(frame(b'S'));until(connection,b'Z')
  if mode=='bind':
   connection.sendall(frame(b'B',b'p\0s\0'+struct.pack('!HHH',0,0,0))+frame(b'H'))
   until(connection,b'2')
  if mode=='describe':
   connection.sendall(frame(b'D',b'Ss\0')+frame(b'H'));until(connection,b'T')
  results[mode+'_idle']=expire(connection)
  if mode!='bind':
   connection.sendall(frame(b'B',b'p\0s\0'+struct.pack('!HHH',0,0,0))+frame(b'H'))
  connection.sendall(frame(b'E',b'p\0'+struct.pack('!I',0))+frame(b'S'))
  executed=until(connection,b'Z')
  results[mode+'_execute']={'errors':[error_state(payload) for kind,payload in executed if kind==b'E'],'rows':sum(kind==b'D' for kind,payload in executed)}
  assert any(kind==b'D' and b'7' in payload for kind,payload in query(connection,'SELECT 7'))
for mode in ['empty', 'row']:
 with connect() as connection:
  query(connection,f'CREATE TABLE timeout_wire_copy_{mode}(id integer)')
  connection.sendall(frame(b'Q',f'COPY timeout_wire_copy_{mode} FROM STDIN'.encode()+b'\0'));until(connection,b'G')
  results['copy_'+mode+'_idle']=expire(connection)
  if mode=='row':connection.sendall(frame(b'd',b'1\n'))
  connection.sendall(frame(b'c'))
  copied=until(connection,b'Z')
  results['copy_'+mode+'_done']={'errors':[error_state(payload) for kind,payload in copied if kind==b'E']}
with connect() as connection, connect() as other:
 query(connection,'SET statement_timeout=0; SET application_name=\'copy-owner\'')
 setup = "CREATE ROLE copy_other; CREATE SCHEMA copy_elsewhere; CREATE TABLE session_copy(id integer); CREATE TABLE session_copy_audit(timing text, level text, owner text);                 CREATE FUNCTION session_copy_trigger() RETURNS trigger LANGUAGE plpgsql AS $$BEGIN                   BEGIN PERFORM set_config('application_name','rolled-back',false); PERFORM 1/0;                   EXCEPTION WHEN division_by_zero THEN                     IF current_setting('application_name') <> 'copy-owner' OR current_user <> 'postgres' OR current_schema() <> 'public' THEN RAISE EXCEPTION 'wrong COPY owner'; END IF;                     INSERT INTO session_copy_audit VALUES(TG_WHEN,TG_LEVEL,current_setting('application_name'));                   END; RETURN NEW; END$$;                 CREATE TRIGGER session_copy_bs BEFORE INSERT ON session_copy FOR EACH STATEMENT EXECUTE FUNCTION session_copy_trigger();                 CREATE TRIGGER session_copy_br BEFORE INSERT ON session_copy FOR EACH ROW EXECUTE FUNCTION session_copy_trigger();                 CREATE TRIGGER session_copy_ar AFTER INSERT ON session_copy FOR EACH ROW EXECUTE FUNCTION session_copy_trigger();                 CREATE TRIGGER session_copy_as AFTER INSERT ON session_copy FOR EACH STATEMENT EXECUTE FUNCTION session_copy_trigger()"
 setup_result=query(connection,setup)
 assert not any(kind==b'E' for kind,payload in setup_result), setup_result
 query(other,"SET statement_timeout=0; SET application_name='other-owner'; SET ROLE copy_other; SET search_path TO copy_elsewhere")
 for binary in [False,True]:
  command='COPY session_copy FROM STDIN'+(' (FORMAT binary)' if binary else '')
  connection.sendall(frame(b'Q',command.encode()+b'\0'));until(connection,b'G')
  query(other,"SELECT current_setting('application_name'), current_user")
  data=(b'PGCOPY\n\xff\r\n\0'+bytes(8)+bytes([0,1,0,0,0,4,0,0,0,2,255,255])) if binary else b'1\n'
  connection.sendall(frame(b'd',data))
  query(other,"SELECT current_setting('application_name'), current_user")
  connection.sendall(frame(b'c'))
  completed=until(connection,b'Z')
  assert not any(kind==b'E' for kind,payload in completed), completed
 observed=query(connection,"SELECT count(*) FROM session_copy_audit WHERE owner='copy-owner'; SELECT count(*) FROM session_copy")
 rows=[payload[6:].decode() for kind,payload in observed if kind==b'D']
 assert rows==['8','2'], rows
 results['copy_trigger_handler_rows']=rows
for continuation in ['parse','bind','describe','execute','flush','close','sync','query']:
 with connect() as connection:
  parse(connection)
  if continuation=='execute':
   connection.sendall(frame(b'B',b'p\0s\0'+struct.pack('!HHH',0,0,0))+frame(b'H'))
   until(connection,b'2')
  assert expire(connection) is None
  messages={
   'parse':frame(b'P',b't\0SELECT 8\0'+struct.pack('!H',0)),
   'bind':frame(b'B',b'p\0s\0'+struct.pack('!HHH',0,0,0)),
   'describe':frame(b'D',b'Ss\0'),
   'execute':frame(b'E',b'p\0'+struct.pack('!I',0)),
   'flush':frame(b'H'),
   'close':frame(b'C',b'Ss\0'),
   'sync':b'',
   'query':frame(b'Q',b'SELECT 99\0'),
  }
  connection.sendall(messages[continuation]+frame(b'S'))
  completed=until(connection,b'Z')
  results['expired_then_'+continuation]={'errors':[error_state(payload) for kind,payload in completed if kind==b'E'],'messages':[kind.decode() for kind,payload in completed]}
Path(destination).write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
assert results['copy_empty_done']['errors']==[]
assert results['copy_row_done']['errors']==['57014']
