import hashlib
import json
from pathlib import Path
import sys
root = Path(sys.argv[1])
for line in (root / 'SHA256SUMS').read_text().splitlines():
    checksum, name = line.split('  ', 1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == checksum, name
provenance = json.loads((root / 'provenance.json').read_text())
assert provenance['version'] == 'postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['observed_error_codes'] == []
assert not (root / 'reference.stderr').read_text()
expected = ['2|row:2','8|call:1','9|call:2|1','3|row:3|10|call:3|1','2|2|row:2','4|4|row:4','NULL|NULL','4','11','11','12','2','NULL|NULL','12|named:12','NULL|NULL','13|named:14','15|wrapped:15','NULL|NULL','16|nested|17','1|checked','1','21','NULL']
assert (root / 'reference.stdout').read_text().splitlines() == expected
assert (root / '244_scalar_functions_in_from.sql').read_bytes() == (root / 'scalar-functions-in-from.sql').read_bytes()
commands = json.loads((root / 'commands.json').read_text())
server = next(command for command in commands if Path(command[0]).name == 'postgres' and '-D' in command)
for setting in ['listen_addresses=', 'shared_buffers=16MB', 'work_mem=1MB', 'max_connections=5', 'statement_timeout=5s', 'lock_timeout=3s']:
    assert setting in server, setting
print('Verified PostgreSQL 18.6: 23 scalar-FROM rows, zero errors, file hashes and bounded server settings')
