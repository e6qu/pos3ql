CREATE TABLE pos3ql_fdw_source(id integer,note text);
