import hashlib
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
files = {}
for line in (root / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert '/' not in name and name not in files
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
    files[name] = digest
assert set(files) == {path.name for path in root.iterdir() if path.is_file()} - {'SHA256SUMS'}
p = json.loads((root / 'provenance.json').read_text())
assert p['version'] == 'postgres (PostgreSQL) 18.6 (Homebrew)'
assert p['observed_error_codes'] == []
assert (root / 'reference.stderr').read_text() == ''
for source, expected in p['sources'].items():
    if Path(source).name in ['owner-reassignment.sql', 'run-owner-reassignment.py']:
        assert files[Path(source).name] == expected
assert (root / 'reference.stdout').read_text().splitlines() == ['owner_reassignment'] + ['reassign_target'] * 3 + ['reassign_source'] * 3 + ['reassign_target'] * 3
print(json.dumps({'verified_files': len(files), 'observed_owners': ['target'] * 3 + ['source'] * 3 + ['target'] * 3}))
