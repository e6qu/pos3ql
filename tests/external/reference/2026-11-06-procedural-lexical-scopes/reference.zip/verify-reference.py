import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
for line in (root/'SHA256SUMS').read_text().splitlines():
 checksum,name=line.split('  ',1)
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==checksum,name
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
codes=['22005','22005','22005','42601','22005','22005']
assert provenance['observed_error_codes']==codes
stderr=(root/'reference.stderr').read_text()
assert re.findall(r'ERROR:\s+([A-Z0-9]{5}):',stderr)==codes
assert not re.search(r'NOTICE:|WARNING:|FATAL:',stderr)
assert len(re.findall(r'LOCATION:  check_assignable, pl_gram.y:',stderr))==4
assert 'LOCATION:  exec_check_assignable, pl_exec.c:' in stderr
assert (root/'reference.stdout').read_text().splitlines()==['1:integer|2:integer|3:integer|4:integer|P0001:caught:7:8:P0001:text:5:integer','0','c','1','22005']
names=['257_diagnostic_counter_scopes.sql','258_procedural_constant_targets.sql']
assert (root/'trigger-context.sql').read_text()=='\n\n'.join((root/name).read_text() for name in names)
commands=json.loads((root/'commands.json').read_text())
server=next(command for command in commands if Path(command[0]).name=='postgres' and '-D' in command)
for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5','statement_timeout=5s','lock_timeout=3s']:
 assert setting in server,setting
print('Verified PostgreSQL18.6:5rows,5compileerrors,1runtimeconstant error,hashes and bounded settings')
