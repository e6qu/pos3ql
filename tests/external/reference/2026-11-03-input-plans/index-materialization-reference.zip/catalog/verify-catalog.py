EXPECTED=['created|2|2|1|2', 'materialized|2|2|1|2', 'inline_key_materialization_pkey|t|t|t', 'inline_key_materialization_value_key|f|t|t', '2|2', 'replaced|2|2|1|2', 'inline_key_materialization_pkey|t|t|t', 'inline_key_materialization_value_key|f|t|t', '0', '1|10|one', '2|20|two']
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert Path(name).name==name and name not in checks
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
assert (root/'planner-drop.sql').read_bytes()==(root/'233_inline_index_materialization.sql').read_bytes()
assert (root/'reference.stdout').read_text().splitlines()==EXPECTED
assert not re.findall(r'ERROR:\s+([A-Z0-9]{5}):',(root/'reference.stderr').read_text())
provenance=json.loads((root/'provenance.json').read_text());assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert checks['233_inline_index_materialization.sql'] in provenance['sources'].values()
commands=json.loads((root/'commands.json').read_text());server=next(c for c in commands if Path(c[0]).name=='postgres' and '-D' in c)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
print(json.dumps({'verified_files':len(checks),'catalog_rows':len(EXPECTED),'qualification':'PostgreSQL reference semantics only'}))
