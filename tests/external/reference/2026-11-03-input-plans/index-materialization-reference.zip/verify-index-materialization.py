import hashlib,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]);checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert not Path(name).is_absolute() and '..' not in Path(name).parts and name not in checks
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 checks[name]=digest
assert set(checks)=={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}-{'SHA256SUMS'}
subprocess.run([sys.executable,str(root/'catalog/verify-catalog.py'),str(root/'catalog')],check=True)
subprocess.run([sys.executable,str(root/'writers/verify-reindex-writer.py'),str(root/'writers')],check=True)
print('index-materialization reference: verified',len(checks),'file hashes')
