STEPS_HASH='1d627a1f6a65d650eea1fbd3b2eb8a2b7dc296783ab57b7defbe99366f40b458'
EXPECTED=[[], [], [], [], ['a_b_c_key'], [], ['a_b_c_key'], ['a_b_c_key'], [], [], ['a_b_c_key'], [], ['a_b_c_key'], ['a_b_c_key'], [], [], ['a_b_c_key'], [], ['a_b_c_key'], ['a_b_c_key'], [], [], ['a_b_c_key'], [], ['a_b_c_key'], ['a_b_c_key']]
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
checks={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert name not in checks and Path(name).name==name
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    checks[name]=digest
assert set(checks)=={p.name for p in root.iterdir() if p.is_file()}-{'SHA256SUMS'}
assert checks['steps.json']==STEPS_HASH
steps=json.loads((root/'steps.json').read_text())
records=[json.loads(line) for line in (root/'reference.jsonl').read_text().splitlines()]
assert len(records)==len(steps)==26
assert [{key:record[key] for key in ['session','label','sql']} for record in records]==steps
assert [record['output'] for record in records]==EXPECTED
assert (root/'reference.sql').read_text()==''.join(f"-- session {step['session']}: {step['label']}\n{step['sql']}\n\n" for step in steps)
for record in records:
    assert not any('ERROR:' in line or 'FATAL:' in line for line in record['output'])
for index in [0,1]:
    assert "SET statement_timeout='3s'" in steps[index]['sql']
    assert "SET lock_timeout='3s'" in steps[index]['sql']
for start,outcome in [(2,'COMMIT'),(8,'ROLLBACK'),(14,'COMMIT'),(20,'ROLLBACK')]:
    assert steps[start+2]['session']==1 and 'second-before-release' in steps[start+2]['label']
    assert steps[start+3]['session']==0 and steps[start+3]['sql']==outcome+';'
    assert records[start+2]['output']==records[start+4]['output']==records[start+5]['output']==['a_b_c_key']
provenance=json.loads((root/'provenance.json').read_text())
assert provenance['version']=='postgres (PostgreSQL) 18.6 (Homebrew)'
assert provenance['project_revision'].startswith('8800db189121059b2d7301a493f37154abd22b92')
assert provenance['primary_source']=='https://github.com/postgres/postgres/blob/REL_18_6/src/backend/catalog/pg_constraint.c#L425-L459'
assert all(re.fullmatch('[0-9a-f]{64}',value) for value in provenance['sources'].values())
assert checks['run-pending-key-namespace.py'] in provenance['sources'].values()
assert {Path(path).name for path in provenance['sources']}=={'run-pending-key-namespace.py','postgres','psql','initdb'}
commands=json.loads((root/'commands.json').read_text())
server=next(command for command in commands if Path(command[0]).name=='postgres' and '-D' in command)
assert all(setting in server for setting in ['listen_addresses=','shared_buffers=16MB','work_mem=1MB','max_connections=5'])
assert len([command for command in commands if Path(command[0]).name=='psql'])==2
assert not re.search(r'ERROR:|FATAL:',(root/'server.log').read_text())
print(json.dumps({'verified_files':len(checks),'exchanges':len(records),'observed_name_rows':sum(len(record['output']) for record in records),'qualification':'PostgreSQL reference semantics only'}))
